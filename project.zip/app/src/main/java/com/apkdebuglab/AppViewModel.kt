package com.apkdebuglab

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.concurrent.atomic.AtomicInteger

data class InstApp(val label: String, val pkg: String, val apk: String)
data class ChatMsg(val fromUser: Boolean, val text: String, val tool: Boolean = false)
data class PendingEdit(val path: String, val find: String, val replace: String, val reason: String)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx: Context = app.applicationContext
    private val prefs = appCtx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    // ---- AI settings ----
    var providerId by mutableStateOf(prefs.getString("provider", "gemini") ?: "gemini")
    var apiKey by mutableStateOf("")
    var baseUrl by mutableStateOf("")
    var model by mutableStateOf("")
    val provider: Provider get() = Providers.byId(providerId)
    val aiReady: Boolean get() = apiKey.isNotBlank() || provider.keyOptional

    private fun loadProviderSettings() {
        val p = provider
        apiKey = prefs.getString("key_${p.id}", "") ?: ""
        baseUrl = prefs.getString("url_${p.id}", p.baseUrl) ?: p.baseUrl
        model = prefs.getString("model_${p.id}", p.model) ?: p.model
    }

    fun saveSettings() {
        val p = provider
        prefs.edit().putString("provider", p.id)
            .putString("key_${p.id}", apiKey.trim())
            .putString("url_${p.id}", baseUrl.trim())
            .putString("model_${p.id}", model.trim()).apply()
        status = "AI settings saved."
    }

    fun selectProvider(id: String) {
        saveSettings()
        providerId = id
        loadProviderSettings()
    }

    fun testConnection() = launchBusy("Testing connection…") {
        val r = Llm.call(
            provider.kind, baseUrl.trim(), apiKey.trim(), model.trim(),
            "You are a connection test.", listOf(UserTurn("Reply with the single word OK.")), JSONArray()
        )
        val e = r.error
        status = if (e != null) e else "Connection works: " + r.text.trim().take(40)
    }

    // ---- global ----
    var home by mutableStateOf(true)
    var status by mutableStateOf("Upload an APK or choose an installed app to start.")
    var busy by mutableStateOf(false)
    private val busyCount = AtomicInteger(0)
    var workspace by mutableStateOf<File?>(null)
    var appName by mutableStateOf("")
    var tab by mutableIntStateOf(0)
    var installed by mutableStateOf<List<InstApp>>(emptyList())
    var res by mutableStateOf<ResTable?>(null)
    @Volatile
    var index: List<IdxFile> = emptyList()
    val concepts = ConceptIndex()
    var skipLibs by mutableStateOf(prefs.getBoolean("skipLibs", true))
    var crashText by mutableStateOf<String?>(null)

    // background code reading
    var bgBusy by mutableStateOf(false)
    var dexTotal by mutableIntStateOf(0)
    var dexDone by mutableIntStateOf(0)

    // ---- preview ----
    var info by mutableStateOf<ManifestInfo?>(null)
    var iconBitmap by mutableStateOf<Bitmap?>(null)
    var layouts by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var candidates by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var candName by mutableStateOf("")
    var previewLayout by mutableStateOf<String?>(null)
    var previewTree by mutableStateOf<UiNode?>(null)
    var selNode by mutableStateOf<UiNode?>(null)
    var inspectHits by mutableStateOf<List<Hit>>(emptyList())
    var inspectRe by mutableStateOf<Regex?>(null)
    var showSheet by mutableStateOf(false)
    var sheetTitle by mutableStateOf("")
    var sheetBlocks by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var sheetFiles by mutableStateOf<List<String>>(emptyList())

    // ---- files ----
    val expanded = mutableStateListOf<String>()
    var tick by mutableIntStateOf(0)
    var openPath by mutableStateOf<String?>(null)
    var openText by mutableStateOf<String?>(null)
    var openSize by mutableStateOf(0L)
    var openLine by mutableIntStateOf(0)
    var editing by mutableStateOf(false)
    var editBuffer by mutableStateOf("")

    // ---- search ----
    var query by mutableStateOf("")
    var useRegex by mutableStateOf(false)
    var caseSens by mutableStateOf(false)
    var extFilter by mutableStateOf("")
    var folderFilter by mutableStateOf("")
    var hits by mutableStateOf<List<Hit>>(emptyList())
    var hlRe by mutableStateOf<Regex?>(null)

    // ---- AI chat ----
    val messages = mutableStateListOf<ChatMsg>()
    var chatInput by mutableStateOf("")
    val pendingEdits = mutableStateListOf<PendingEdit>()
    var autoApply by mutableStateOf(false)
    private val turns = ArrayList<Turn>()
    private val undoList = ArrayList<Pair<String, String>>()
    var undoCount by mutableIntStateOf(0)

    // ---- build ----
    var lastApk by mutableStateOf<File?>(null)
    var buildLog by mutableStateOf("")

    // ---------- plumbing ----------

    private var heavyCount = 0

    private fun keepAlive(on: Boolean) {
        try {
            synchronized(this) {
                if (on) {
                    heavyCount++
                    if (heavyCount == 1) {
                        ContextCompat.startForegroundService(appCtx, Intent(appCtx, KeepAliveService::class.java))
                    }
                } else {
                    heavyCount = maxOf(0, heavyCount - 1)
                    if (heavyCount == 0) appCtx.stopService(Intent(appCtx, KeepAliveService::class.java))
                }
            }
        } catch (t: Throwable) {
        }
    }

    private fun launchBusy(msg: String, heavy: Boolean = false, block: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            busy = busyCount.incrementAndGet() > 0
            if (heavy) keepAlive(true)
            status = msg
            try {
                block()
            } catch (t: Throwable) {
                status = "Error: " + (t.message ?: t.javaClass.simpleName)
                buildLog += "\n" + t.stackTraceToString().take(1500)
            } finally {
                if (heavy) keepAlive(false)
                busy = busyCount.decrementAndGet() > 0
            }
        }
    }

    // ---------- saved state (survives the app being closed or killed) ----------

    private var lastChatSig = -1

    private fun saveChat() {
        val sig = messages.size * 1000 + pendingEdits.size
        if (sig == lastChatSig) return
        lastChatSig = sig
        val arr = JSONArray()
        for (m in messages.takeLast(80)) {
            arr.put(JSONObject().put("u", m.fromUser).put("t", m.text.take(6000)).put("k", m.tool))
        }
        val pe = JSONArray()
        for (e in pendingEdits.toList()) {
            pe.put(JSONObject().put("p", e.path).put("f", e.find).put("r", e.replace).put("w", e.reason))
        }
        File(appCtx.filesDir, "chat.json").writeText(JSONObject().put("m", arr).put("e", pe).toString())
    }

    private fun loadChat() {
        val f = File(appCtx.filesDir, "chat.json")
        if (!f.exists()) return
        try {
            val o = JSONObject(f.readText())
            val a = o.optJSONArray("m")
            if (a != null) {
                for (i in 0 until a.length()) {
                    val m = a.getJSONObject(i)
                    messages.add(ChatMsg(m.optBoolean("u"), m.optString("t"), m.optBoolean("k")))
                }
            }
            val pe = o.optJSONArray("e")
            if (pe != null) {
                for (i in 0 until pe.length()) {
                    val e = pe.getJSONObject(i)
                    pendingEdits.add(PendingEdit(e.optString("p"), e.optString("f"), e.optString("r"), e.optString("w")))
                }
            }
        } catch (t: Throwable) {
        }
        lastChatSig = messages.size * 1000 + pendingEdits.size
    }

    private fun saveState() {
        try {
            prefs.edit()
                .putBoolean("ui_home", home).putInt("ui_tab", tab)
                .putString("ui_open", openPath ?: "").putInt("ui_line", openLine)
                .putString("ui_layout", previewLayout ?: "")
                .putString("ui_query", query).putBoolean("ui_regex", useRegex).putBoolean("ui_case", caseSens)
                .putString("ui_ext", extFilter).putString("ui_folder", folderFilter)
                .apply()
            saveChat()
        } catch (t: Throwable) {
        }
    }

    fun flushState() {
        viewModelScope.launch(Dispatchers.IO) { saveState() }
    }

    private fun startAutoSave() {
        viewModelScope.launch(Dispatchers.Default) {
            snapshotFlow {
                listOf<Any?>(
                    home, tab, openPath, openLine, previewLayout, query, useRegex, caseSens,
                    extFilter, folderFilter, messages.size, pendingEdits.size
                )
            }.collect { saveState() }
        }
    }

    fun updateSkipLibs(v: Boolean) {
        skipLibs = v
        prefs.edit().putBoolean("skipLibs", v).apply()
    }

    fun dismissCrash() {
        File(appCtx.filesDir, "crash.txt").delete()
        crashText = null
    }

    // ---------- helpers used by search / preview / agent ----------

    fun buildRegex(q: String, regex: Boolean, caseSens: Boolean): Regex {
        val opts: Set<RegexOption> = if (caseSens) emptySet() else setOf(RegexOption.IGNORE_CASE)
        if (regex) return Regex(q, opts)
        val parts = ArrayList<String>()
        parts.add(Regex.escape(q))
        val t = res
        if (t != null) {
            val key = q.trim().removePrefix("@").removePrefix("+")
            val ids = ArrayList<Int>()
            if (key.contains('/')) {
                t.nameToId[key]?.let { ids.add(it) }
            } else if (key.length >= 3 && key.all { it.isLetterOrDigit() || it == '_' }) {
                for (type in listOf("id", "string", "layout", "drawable", "color", "menu", "mipmap", "dimen", "style")) {
                    t.nameToId["$type/$key"]?.let { ids.add(it) }
                }
            }
            for (id in ids.take(6)) parts.add(Regex.escape(t.hex(id)))
        }
        return Regex(parts.joinToString("|"), opts)
    }

    fun currentRegex(): Regex? {
        if (query.isBlank()) return null
        return try {
            buildRegex(query, useRegex, caseSens)
        } catch (e: Exception) {
            null
        }
    }

    fun resolveText(s: String): String {
        if (!s.startsWith("@")) return s
        val t = res ?: return s
        return t.firstValue(s.removePrefix("@")) ?: s
    }

    fun showHits(q: String, rx: Boolean, h: List<Hit>) {
        query = q
        useRegex = rx
        hlRe = null
        hits = h
        status = "${h.size} matches in ${h.map { it.path }.distinct().size} files"
    }

    fun showFeatureHits(q: String, h: List<Hit>) {
        hlRe = Concept.highlight(q)
        hits = h
        status = "${h.size} feature matches"
    }

    // ---------- import (fast phase) ----------

    fun loadInstalled() = launchBusy("Loading installed apps…") {
        val pm = appCtx.packageManager
        installed = pm.getInstalledApplications(0)
            .map { InstApp(pm.getApplicationLabel(it).toString(), it.packageName, it.sourceDir) }
            .sortedBy { it.label.lowercase() }
        status = "${installed.size} apps found."
    }

    fun importUri(uri: Uri) {
        val name = (uri.lastPathSegment ?: "app").substringAfterLast('/').substringBeforeLast('.')
        importFrom(name) { appCtx.contentResolver.openInputStream(uri)!! }
    }

    fun importInstalled(a: InstApp) = importFrom(a.label) { File(a.apk).inputStream() }

    private fun copyWithProgress(open: () -> InputStream, dest: File) {
        open().use { i ->
            dest.outputStream().buffered(1 shl 18).use { o ->
                val buf = ByteArray(1 shl 18)
                var total = 0L
                var last = 0L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    total += n
                    if (total - last > 4_000_000) {
                        last = total
                        status = "Copying APK… ${total / 1_000_000} MB"
                    }
                }
            }
        }
    }

    private fun importFrom(name: String, open: () -> InputStream) = launchBusy("Copying APK…", true) {
        val ws = File(appCtx.filesDir, "ws")
        ws.deleteRecursively()
        ws.mkdirs()
        File(appCtx.filesDir, "chat.json").delete()
        messages.clear()
        pendingEdits.clear()
        turns.clear()
        undoList.clear()
        undoCount = 0
        concepts.clear()
        index = emptyList()
        dexTotal = 0
        dexDone = 0
        copyWithProgress(open, File(ws, "original.apk"))
        status = "Unpacking…"
        ApkTools.unzip(File(ws, "original.apk"), File(ws, "files"), File(ws, "stored.txt"))
        var log = ""

        status = "Reading resources…"
        val arsc = File(ws, "files/resources.arsc")
        val table = if (arsc.exists()) {
            try {
                Axml.parseResTable(arsc.readBytes())
            } catch (t: Throwable) {
                log += "resources.arsc not parsed: ${t.message}\n"
                null
            }
        } else null

        status = "Decoding manifest and layouts…"
        val n = decodeXmls(ws, table)
        log += "Decoded $n XML files\n"
        if (table != null) {
            val ents = Concept.writeRes(ws, table)
            Concept.save(File(ws, "concepts/res.tsv"), ents)
            concepts.add(ents)
        }
        File(ws, ".imported").writeText(System.currentTimeMillis().toString())
        File(ws, "meta.txt").writeText(name)

        appName = name
        res = table
        loadDerived(ws)
        buildLog = log
        expanded.clear()
        hits = emptyList()
        hlRe = null
        openPath = null
        openText = null
        lastApk = null
        previewLayout = null
        previewTree = null
        selNode = null
        showSheet = false
        candidates = emptyList()
        workspace = ws
        home = false
        tab = 0
        tick++
        status = "Preview is ready. Reading the code in the background…"
        autoPreviewLauncher()
        startDisassembly(ws)
    }

    private fun decodeXmls(ws: File, t: ResTable?): Int {
        val files = File(ws, "files")
        val outRoot = File(ws, "xml")
        var n = 0
        for (f in files.walkTopDown()) {
            if (!f.isFile || !f.name.endsWith(".xml")) continue
            try {
                val head = ByteArray(4)
                f.inputStream().use { it.read(head) }
                if (!Axml.isBinaryXml(head)) continue
                val text = Axml.decode(f.readBytes(), t)
                val out = File(outRoot, f.relativeTo(files).path)
                out.parentFile?.mkdirs()
                out.writeText(text)
                n++
            } catch (e: Exception) {
            }
        }
        return n
    }

    // ---------- background code reading (smali) ----------

    private fun startDisassembly(ws: File) {
        if (bgBusy) return
        val pending = File(ws, "files").listFiles()
            ?.filter { it.isFile && Regex("classes\\d*\\.dex").matches(it.name) }
            ?.any { !File(ws, "smali/" + it.nameWithoutExtension + "/.done").exists() } ?: false
        if (!pending) return
        viewModelScope.launch(Dispatchers.IO) {
            bgBusy = true
            keepAlive(true)
            try {
                runDisassembly(ws)
            } catch (t: Throwable) {
                buildLog += "Background reading stopped: ${t.message}\n"
            } finally {
                bgBusy = false
                keepAlive(false)
            }
        }
    }

    private fun runDisassembly(ws: File) {
        val dexes = File(ws, "files").listFiles()
            ?.filter { it.isFile && Regex("classes\\d*\\.dex").matches(it.name) }
            ?.sortedBy { it.name } ?: emptyList()
        dexTotal = dexes.size
        dexDone = 0
        for (d in dexes) {
            val out = File(ws, "smali/" + d.nameWithoutExtension)
            val done = File(out, ".done")
            if (done.exists()) {
                dexDone++
                continue
            }
            status = "Reading code in ${d.name} (${dexDone + 1}/${dexes.size}). You can keep using the app."
            try {
                out.deleteRecursively()
                out.mkdirs()
                DexTools.disassemble(d, out, skipLibs)
                val ents = Concept.scanSmali(ws, out)
                Concept.save(File(ws, "concepts/" + d.nameWithoutExtension + ".tsv"), ents)
                concepts.add(ents)
                index = index + Searcher.indexDir(ws, out)
                done.writeText(System.currentTimeMillis().toString())
            } catch (t: Throwable) {
                buildLog += "Could not read ${d.name}: ${t.message}\n"
            }
            dexDone++
            tick++
        }
        status = "Code is ready: ${index.size} searchable files, ${concepts.size()} searchable names."
    }

    /** Index, manifest info, icon and layout list (after import and on restore). */
    private fun loadDerived(ws: File) {
        index = Searcher.buildIndex(ws)
        val mf = File(ws, "xml/AndroidManifest.xml")
        info = if (mf.exists()) {
            try {
                Preview.parseManifest(mf.readText(), this::resolveText)
            } catch (t: Throwable) {
                null
            }
        } else null
        iconBitmap = try {
            loadIcon(ws, info?.iconRef)
        } catch (t: Throwable) {
            null
        }
        val t = res
        layouts = if (t == null) emptyList() else {
            t.names.entries.filter { it.value.startsWith("layout/") }.mapNotNull { e ->
                val v = t.values[e.key]?.firstOrNull { it.endsWith(".xml") }
                if (v != null && File(ws, "xml/$v").exists()) e.value to "xml/$v" else null
            }.distinctBy { it.second }.sortedBy { it.first }
        }
    }

    private fun loadIcon(ws: File, iconRef: String?): Bitmap? {
        val t = res ?: return null
        val id = iconRef?.removePrefix("@")?.let { t.nameToId[it] } ?: return null
        val best = (t.values[id] ?: emptyList<String>())
            .map { File(ws, "files/$it") }
            .filter { it.isFile && (it.name.endsWith(".png") || it.name.endsWith(".webp")) }
            .maxByOrNull { it.length() } ?: return null
        val o = BitmapFactory.Options()
        o.inSampleSize = 2
        return BitmapFactory.decodeFile(best.absolutePath, o)
    }

    private fun restore() {
        val crash = File(appCtx.filesDir, "crash.txt")
        if (crash.exists()) crashText = try { crash.readText() } catch (t: Throwable) { null }
        val ws = File(appCtx.filesDir, "ws")
        if (!File(ws, ".imported").exists()) return
        val mf = File(ws, "meta.txt")
        appName = if (mf.exists()) mf.readText().trim() else "last app"
        val arsc = File(ws, "files/resources.arsc")
        res = if (arsc.exists()) {
            try {
                Axml.parseResTable(arsc.readBytes())
            } catch (t: Throwable) {
                null
            }
        } else null
        loadDerived(ws)
        concepts.clear()
        Concept.loadAll(File(ws, "concepts"), concepts)
        loadChat()
        workspace = ws
        home = prefs.getBoolean("ui_home", false)
        query = prefs.getString("ui_query", "") ?: ""
        useRegex = prefs.getBoolean("ui_regex", false)
        caseSens = prefs.getBoolean("ui_case", false)
        extFilter = prefs.getString("ui_ext", "") ?: ""
        folderFilter = prefs.getString("ui_folder", "") ?: ""
        val savedTab = prefs.getInt("ui_tab", 0)
        val op = prefs.getString("ui_open", "") ?: ""
        if (op.isNotEmpty() && File(ws, op).isFile) loadFile(op, prefs.getInt("ui_line", 0))
        val pl = prefs.getString("ui_layout", "") ?: ""
        if (pl.isNotEmpty() && File(ws, pl).isFile) showLayoutNow(pl)
        tab = savedTab.coerceIn(0, 4)
        status = "Restored $appName where you left off."
        startDisassembly(ws)
    }

    fun clearWorkspace() = launchBusy("Deleting saved app…") {
        if (bgBusy) {
            status = "Wait for the code reading to finish first."
            return@launchBusy
        }
        File(appCtx.filesDir, "ws").deleteRecursively()
        File(appCtx.filesDir, "chat.json").delete()
        workspace = null
        home = true
        messages.clear()
        pendingEdits.clear()
        hits = emptyList()
        info = null
        iconBitmap = null
        layouts = emptyList()
        closePreview()
        closeFile()
        index = emptyList()
        concepts.clear()
        status = "Saved app deleted."
    }

    // ---------- preview & inspector ----------

    private fun findClassRel(cls: String): String? {
        val tail = "/" + cls.replace('.', '/') + ".smali"
        return index.firstOrNull { it.rel.endsWith(tail) }?.rel
    }

    fun openClass(cls: String) {
        val rel = findClassRel(cls)
        if (rel == null) {
            status = if (bgBusy) "Code is still loading ($dexDone/$dexTotal). Try again in a moment." else "Class file not found: $cls"
        } else open(rel)
    }

    private fun guessLayouts(cls: String): List<Pair<String, String>> {
        val simple = cls.substringAfterLast('.').substringAfterLast('$')
        val base = Concept.words(simple).filter { it != "activity" }
        if (base.isEmpty()) return emptyList()
        val joined = base.joinToString("_")
        val wanted = listOf("activity_$joined", joined + "_activity", joined, "layout_$joined")
        val exact = layouts.filter { l -> wanted.any { w -> l.first.substringAfter('/').equals(w, true) } }
        if (exact.isNotEmpty()) return exact
        return layouts.filter { it.first.contains(joined, true) }.take(5)
    }

    private fun openActivityNow(cls: String) {
        val ws = workspace ?: return
        val t = res
        candName = cls.substringAfterLast('.')
        candidates = emptyList()
        val found = ArrayList<Pair<String, String>>()
        val rel = findClassRel(cls)
        if (rel != null && t != null) {
            val text = File(ws, rel).readText()
            val ids = Regex("0x7f[0-9a-fA-F]{6}").findAll(text)
                .map { it.value.substring(2).toLong(16).toInt() }.toSet()
            for (id in ids) {
                val nm = t.names[id] ?: continue
                if (!nm.startsWith("layout/")) continue
                val v = t.values[id]?.firstOrNull { it.endsWith(".xml") } ?: continue
                if (File(ws, "xml/$v").exists()) found.add(nm to "xml/$v")
            }
        }
        if (found.isEmpty()) found.addAll(guessLayouts(cls))
        candidates = found.distinctBy { it.second }
        if (candidates.size == 1) {
            showLayoutNow(candidates[0].second)
        } else {
            status = if (candidates.isEmpty()) {
                if (bgBusy) "Code is still loading, so the layout can't be matched yet. Try again shortly."
                else "No layout found for this screen (it may use fragments). Open the code instead."
            } else "${candidates.size} layouts used by $candName. Pick one."
        }
    }

    private fun autoPreviewLauncher() {
        val a = info?.activities?.firstOrNull { it.launcher } ?: info?.activities?.firstOrNull() ?: return
        try {
            openActivityNow(a.name)
        } catch (t: Throwable) {
        }
    }

    fun openActivity(cls: String) = launchBusy("Finding this screen's layout…") { openActivityNow(cls) }

    private fun showLayoutNow(rel: String) {
        val ws = workspace ?: return
        val tree = Preview.parseLayout(File(ws, rel).readText())
        previewLayout = rel
        previewTree = tree
        selNode = null
        showSheet = false
        inspectHits = emptyList()
        inspectRe = null
        status = if (tree == null) "This layout can't be drawn; open its code." else rel.removePrefix("xml/")
    }

    fun showLayout(rel: String) = launchBusy("Rendering layout…") { showLayoutNow(rel) }

    fun closePreview() {
        previewLayout = null
        previewTree = null
        selNode = null
        showSheet = false
        inspectHits = emptyList()
        inspectRe = null
    }

    private fun buildSheet(ws: File, title: String, layoutHit: Hit?, layoutRadius: Int, h: List<Hit>) {
        val blocks = ArrayList<Pair<String, String>>()
        if (layoutHit != null) {
            blocks.add("${layoutHit.path}:${layoutHit.line}" to Searcher.context(ws, layoutHit, layoutRadius))
        }
        val seen = HashSet<String>()
        for (x in h) {
            if (blocks.size >= 6) break
            val c = Searcher.context(ws, x)
            val key = x.path + "|" + c.lineSequence().firstOrNull().orEmpty()
            if (c.isNotBlank() && seen.add(key)) blocks.add("${x.path}:${x.line}" to c.take(3500))
        }
        sheetTitle = title
        sheetBlocks = blocks
        sheetFiles = h.map { it.path }.distinct().take(12)
        showSheet = true
    }

    fun inspectNode(n: UiNode, deep: Boolean) {
        selNode = n
        launchBusy("Finding code for this element…") {
            val ws = workspace ?: return@launchBusy
            val t = res
            val parts = ArrayList<String>()
            fun addRes(refStr: String?) {
                if (refStr == null || t == null) return
                val id = t.nameToId[refStr.removePrefix("@").removePrefix("+")] ?: return
                parts.add(Regex.escape(t.hex(id)))
            }
            val idAttr = n.attrs["android:id"]
            addRes(idAttr)
            addRes(n.attrs["android:text"])
            addRes(n.attrs["android:hint"])
            addRes(n.attrs["android:src"])
            addRes(n.attrs["android:background"])
            addRes(n.attrs["android:contentDescription"])
            val click = n.attrs["android:onClick"]
            if (!click.isNullOrBlank()) parts.add("\\.method.* " + Regex.escape(click) + "\\(")
            if (idAttr != null) parts.add(Regex.escape(idAttr))
            val layoutHit = previewLayout?.let { Hit(it, maxOf(1, n.line), "") }
            if (parts.isEmpty()) {
                inspectHits = emptyList()
                inspectRe = null
                status = "This block has no id, text or click handler to trace."
                if (deep && layoutHit != null) buildSheet(ws, n.tag.substringAfterLast('.'), layoutHit, 8, emptyList())
                return@launchBusy
            }
            val re = Regex(parts.joinToString("|"))
            inspectRe = re
            val r = Searcher.search(index, re, emptyList(), "", 80)
            inspectHits = r
            status = "${r.size} related lines in ${r.map { it.path }.distinct().size} files" +
                (if (bgBusy) " (code still loading $dexDone/$dexTotal)" else "")
            if (deep) {
                buildSheet(
                    ws, n.tag.substringAfterLast('.') + (idAttr?.let { "  $it" } ?: ""),
                    layoutHit, 8, r.filter { !it.path.startsWith("xml/res_ids") }
                )
            }
        }
    }

    /** Double tap on empty space: show the code behind the whole screen. */
    fun inspectLayout() = launchBusy("Finding code for this screen…") {
        val ws = workspace ?: return@launchBusy
        val rel = previewLayout ?: return@launchBusy
        val t = res
        val name = layouts.firstOrNull { it.second == rel }?.first
        var r: List<Hit> = emptyList()
        var hl: Regex? = null
        if (t != null && name != null) {
            val id = t.nameToId[name]
            if (id != null) {
                hl = Regex(Regex.escape(t.hex(id)))
                r = Searcher.search(index, hl, emptyList(), "", 40).filter { !it.path.startsWith("xml/res_ids") }
            }
        }
        inspectRe = hl
        buildSheet(ws, rel.removePrefix("xml/"), Hit(rel, 1, ""), 40, r)
    }

    fun askAboutElement(n: UiNode) {
        val attrs = n.attrs.entries.filter { !it.key.startsWith("xmlns") }
            .joinToString(" ") { it.key + "=\"" + it.value + "\"" }
        ask(
            "Explain this UI element and trace the code behind it (click handlers, where its id is used, " +
                "what happens next). Element: <${n.tag} $attrs> at ${previewLayout}:${n.line}"
        )
    }

    fun editWithAI(instruction: String) {
        val ctx = sheetBlocks.take(2).joinToString("\n\n") { it.first + "\n" + it.second.take(1500) }
        ask("Make this change in the app's code: $instruction\n\nContext (${sheetTitle}):\n$ctx")
    }

    // ---------- files ----------

    private fun loadFile(path: String, line: Int) {
        val ws = workspace ?: return
        val f = File(ws, path)
        openPath = path
        openLine = line
        editing = false
        openSize = f.length()
        openText = if ((path.endsWith(".smali") || Searcher.isText(f)) && f.length() < 8_000_000) f.readText() else null
        tab = 1
        status = path
    }

    fun open(path: String, line: Int = 0) = launchBusy("Opening…") { loadFile(path, line) }

    fun closeFile() {
        openPath = null
        openText = null
        editing = false
    }

    fun saveOpen() = launchBusy("Saving…") {
        val ws = workspace ?: return@launchBusy
        val p = openPath ?: return@launchBusy
        val f = File(ws, p)
        undoList.add(p to f.readText())
        undoCount = undoList.size
        f.writeText(editBuffer)
        openText = editBuffer
        editing = false
        tick++
        status = "Saved $p"
    }

    fun replaceOpen(uri: Uri) = launchBusy("Replacing file…") {
        val ws = workspace ?: return@launchBusy
        val p = openPath ?: return@launchBusy
        appCtx.contentResolver.openInputStream(uri)?.use { i ->
            File(ws, p).outputStream().use { o -> i.copyTo(o) }
        }
        tick++
        loadFile(p, 0)
        status = "Replaced $p"
    }

    // ---------- search ----------

    fun runSearch() = launchBusy("Searching…") {
        if (workspace == null) return@launchBusy
        if (query.isBlank()) {
            status = "Type something to search."
            return@launchBusy
        }
        val exts = extFilter.split(",", " ").map { it.trim().trimStart('.').lowercase() }.filter { it.isNotEmpty() }
        val re = buildRegex(query, useRegex, caseSens)
        hlRe = null
        val r = Searcher.search(index, re, exts, folderFilter.trim())
        hits = r
        status = "${r.size}${if (r.size >= Searcher.MAX) "+" else ""} matches in ${r.map { it.path }.distinct().size} files" +
            (if (bgBusy) " (code still loading $dexDone/$dexTotal)" else "")
    }

    fun contextFor(h: Hit): String {
        val ws = workspace ?: return ""
        return Searcher.context(ws, h)
    }

    fun usages(h: Hit) {
        query = Searcher.usageQuery(h)
        useRegex = false
        caseSens = true
        extFilter = ""
        folderFilter = ""
        tab = 2
        runSearch()
    }

    fun askAbout(h: Hit) {
        chatInput = "Explain this code, trace what calls it, and point out any bugs:\n[${h.path}:${h.line}]\n" + contextFor(h)
        tab = 3
    }

    /** Search by what something does ("block generator"), with no AI needed. */
    fun featureHits(q: String): List<Hit> {
        val found = concepts.search(q, 40)
        val out = ArrayList<Hit>()
        val seen = HashSet<String>()
        for (e in found) {
            if (seen.add(e.path + ":" + e.line)) out.add(Hit(e.path, e.line, Concept.display(e)))
        }
        var follow = 0
        for (e in found) {
            if (follow >= 3) break
            if ((e.kind == 'r' || e.kind == 'l') && e.extra.isNotEmpty()) {
                follow++
                for (h in Searcher.search(index, Regex(Regex.escape(e.extra)), emptyList(), "", 6)) {
                    if (!h.path.startsWith("xml/res_ids") && seen.add(h.path + ":" + h.line)) out.add(h)
                }
            }
        }
        if (out.isEmpty()) {
            val re = Concept.highlight(q)
            if (re != null) out.addAll(Searcher.search(index, re, emptyList(), "", 40))
        }
        return out.groupBy { it.path }.values.flatten()
    }

    fun conceptSearch(q: String) = launchBusy("Searching by feature…") {
        if (workspace == null || q.isBlank()) return@launchBusy
        val h = featureHits(q)
        showFeatureHits(q, h)
        tab = 2
        status = "${h.size} feature matches" + (if (bgBusy) " (code still loading $dexDone/$dexTotal)" else "")
    }

    // ---------- AI agent ----------

    fun ask(question: String) {
        chatInput = question
        tab = 3
        sendChat(false, false)
    }

    fun sendChat(withSearch: Boolean, withFile: Boolean) {
        val typed = chatInput.trim()
        if (typed.isEmpty()) return
        if (!aiReady) {
            status = "Add an AI key under Home > AI settings (free options available)."
            return
        }
        val ws = workspace
        val sb = StringBuilder(typed)
        if (withSearch && ws != null && hits.isNotEmpty()) {
            sb.append("\n\n--- Current search results ---\n")
            for (h in hits.take(8)) {
                sb.append("\n[").append(h.path).append(':').append(h.line).append("]\n")
                sb.append(Searcher.context(ws, h))
            }
        }
        val ot = openText
        if (withFile && ot != null) {
            sb.append("\n\n--- Open file: ").append(openPath).append(" ---\n").append(ot.take(12000))
        }
        messages.add(ChatMsg(true, typed.take(1500)))
        chatInput = ""
        runAgent(sb.toString().take(30000))
    }

    private fun turnSize(t: Turn): Int = when (t) {
        is UserTurn -> t.text.length
        is AssistTurn -> t.text.length + t.calls.sumOf { c -> c.input.toString().length }
        is ResultTurn -> t.results.sumOf { r -> r.second.length }
    }

    /** Keeps requests small for slow connections: old tool output is shortened. */
    private fun pruneTurns() {
        var total = 0
        for (t in turns) total += turnSize(t)
        if (total > 200_000) {
            turns.clear()
            messages.add(ChatMsg(false, "(Conversation memory was reset to stay within limits.)", true))
            return
        }
        if (total > 50_000) {
            for (i in 0 until maxOf(0, turns.size - 4)) {
                val t = turns[i]
                if (t is ResultTurn) {
                    turns[i] = ResultTurn(t.results.map { r -> r.first to r.second.take(300) })
                }
            }
        }
    }

    private fun brief(c: ToolCall): String {
        val q = c.input.optString("query").ifBlank { c.input.optString("description") }
        return if (q.isNotBlank()) q else c.input.optString("path").ifBlank { c.input.optString("name") }
    }

    private fun runAgent(userText: String) = launchBusy("AI is working…") {
        pruneTurns()
        turns.add(UserTurn(userText))
        for (round in 0 until 10) {
            status = "AI is working (step ${round + 1})…"
            val r = Llm.call(provider.kind, baseUrl.trim(), apiKey.trim(), model.trim(), Agent.SYSTEM, turns.toList(), Agent.tools)
            val err = r.error
            if (err != null) {
                messages.add(ChatMsg(false, err))
                if (round == 0) turns.removeAt(turns.size - 1)
                status = "AI error"
                return@launchBusy
            }
            turns.add(AssistTurn(r.text, r.calls))
            if (r.text.isNotBlank()) messages.add(ChatMsg(false, r.text))
            if (r.calls.isEmpty()) {
                status = "Done."
                return@launchBusy
            }
            val results = ArrayList<Pair<String, String>>()
            for (c in r.calls) {
                messages.add(ChatMsg(false, "${c.name}: ${brief(c)}", true))
                val out = try {
                    Agent.execute(this, c.name, c.input)
                } catch (e: Exception) {
                    "Tool error: ${e.message}"
                }
                results.add(c.id to out.take(6000))
            }
            turns.add(ResultTurn(results))
        }
        messages.add(ChatMsg(false, "(Stopped after 10 steps. Ask me to continue.)", true))
    }

    // ---------- edits (AI proposals, undo) ----------

    fun applyEdit(e: PendingEdit): String {
        val ws = workspace ?: return "No app open"
        val f = File(ws, e.path)
        if (!f.isFile) return "File not found"
        val text = f.readText()
        val i = text.indexOf(e.find)
        if (i < 0) return "Text not found anymore"
        if (text.indexOf(e.find, i + 1) >= 0) return "Matches several places"
        synchronized(undoList) {
            undoList.add(e.path to text)
            undoCount = undoList.size
        }
        f.writeText(text.replaceRange(i, i + e.find.length, e.replace))
        tick++
        if (openPath == e.path) openText = f.readText()
        return "Applied to ${e.path}"
    }

    fun undoLast() = launchBusy("Undoing…") {
        val ws = workspace ?: return@launchBusy
        val last = synchronized(undoList) {
            if (undoList.isEmpty()) null else undoList.removeAt(undoList.size - 1).also { undoCount = undoList.size }
        } ?: return@launchBusy
        File(ws, last.first).writeText(last.second)
        if (openPath == last.first) openText = last.second
        tick++
        status = "Undid the last edit in ${last.first}"
    }

    fun approve(e: PendingEdit) = launchBusy("Applying edit…") {
        val r = applyEdit(e)
        pendingEdits.remove(e)
        status = r
    }

    fun approveAll() = launchBusy("Applying edits…") {
        val list = pendingEdits.toList()
        var ok = 0
        for (e in list) {
            if (applyEdit(e).startsWith("Applied")) ok++
            pendingEdits.remove(e)
        }
        status = "Applied $ok of ${list.size} edits."
    }

    fun dismiss(e: PendingEdit) {
        pendingEdits.remove(e)
    }

    // ---------- build (only edited classes are reassembled, so it is fast) ----------

    fun rebuild() = launchBusy("Rebuilding…", true) {
        val ws = workspace ?: return@launchBusy
        val files = File(ws, "files")
        var log = ""
        val changed = ArrayList<File>()
        var incomplete = false
        File(ws, "smali").listFiles()?.filter { it.isDirectory }?.forEach { d ->
            val done = File(d, ".done")
            if (!done.exists()) {
                incomplete = true
                return@forEach
            }
            val stamp = done.lastModified() + 1500
            d.walkTopDown().filter { it.isFile && it.name.endsWith(".smali") && it.lastModified() > stamp }
                .forEach { changed.add(it) }
        }
        if (incomplete) log += "Note: some code was still loading; edits there are not included.\n"
        var patch: File? = null
        if (changed.isNotEmpty()) {
            status = "Assembling ${changed.size} edited classes…"
            val p = File(ws, "patch.dex")
            DexTools.assembleFiles(changed, p)
            patch = p
            log += "Patched ${changed.size} classes\n"
        }
        status = "Packing APK…"
        val unsigned = File(ws, "unsigned.apk")
        ApkTools.repack(files, File(ws, "stored.txt"), unsigned, patch)
        status = "Signing APK…"
        val outDir = File(appCtx.filesDir, "out")
        outDir.mkdirs()
        val safe = appName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val out = File(outDir, "$safe-edited.apk")
        ApkTools.sign(appCtx, unsigned, out)
        unsigned.delete()
        patch?.delete()
        lastApk = out
        buildLog = log + "Built ${out.name} (${sizeStr(out.length())})\n"
        status = "APK ready: ${out.name}"
    }

    fun saveApkTo(uri: Uri) = launchBusy("Saving copy…") {
        val apk = lastApk ?: return@launchBusy
        appCtx.contentResolver.openOutputStream(uri)?.use { o -> apk.inputStream().use { it.copyTo(o) } }
        status = "Saved a copy."
    }

    init {
        loadProviderSettings()
        launchBusy("Restoring last app…") {
            try {
                restore()
            } finally {
                startAutoSave()
            }
        }
    }
}
