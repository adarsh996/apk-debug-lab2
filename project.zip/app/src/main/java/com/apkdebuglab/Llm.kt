package com.apkdebuglab

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ---------- provider presets (so the app works with free keys, not only Anthropic) ----------

data class Provider(
    val id: String, val label: String, val kind: String,
    val baseUrl: String, val model: String, val keyOptional: Boolean, val hint: String
)

object Providers {
    val all = listOf(
        Provider(
            "gemini", "Gemini (free tier)", "openai",
            "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", false,
            "Free key: aistudio.google.com/apikey (sign in with Google, no card needed)."
        ),
        Provider(
            "groq", "Groq (free tier)", "openai",
            "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", false,
            "Free key: console.groq.com/keys. Fast, with daily limits."
        ),
        Provider(
            "openrouter", "OpenRouter", "openai",
            "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", false,
            "Key: openrouter.ai/keys. Models ending in :free cost nothing."
        ),
        Provider(
            "anthropic", "Claude (Anthropic)", "anthropic",
            "https://api.anthropic.com", "claude-sonnet-5-5", false,
            "Key: console.anthropic.com. This is billed separately from a claude.ai subscription and needs prepaid credit."
        ),
        Provider(
            "local", "Local / custom server", "openai",
            "http://192.168.1.10:11434/v1", "llama3.1", true,
            "Ollama or any OpenAI-compatible server on your Wi-Fi. Use a model that supports tools. Key can stay empty."
        )
    )

    fun byId(id: String): Provider = all.firstOrNull { it.id == id } ?: all[0]
}

// ---------- neutral conversation format ----------

class ToolCall(val id: String, val name: String, val input: JSONObject)
sealed class Turn
class UserTurn(val text: String) : Turn()
class AssistTurn(val text: String, val calls: List<ToolCall>) : Turn()
class ResultTurn(val results: List<Pair<String, String>>) : Turn()
class LlmReply(val text: String, val calls: List<ToolCall>, val error: String?)

object Llm {
    private fun friendly(code: Int, body: String): String {
        val b = body.take(300)
        return when (code) {
            401, 403 -> "The provider rejected the API key ($code). Check the key and provider under Home > AI settings. $b"
            402 -> "This account has no credit left. Add credit, or switch to a free provider under Home > AI settings. $b"
            404 -> "Model or URL not found. Check the model name and base URL under Home > AI settings. $b"
            429 -> "Rate limit or free quota reached. Wait a minute and retry, or switch provider. $b"
            else -> "API error $code: $b"
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 30000
        c.readTimeout = 150000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return code to txt
    }

    /** Retries timeouts, dropped connections, 429 and 5xx so slow or flaky internet still works. */
    private fun postRetry(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        var last: Exception? = null
        for (attempt in 0 until 3) {
            try {
                val r = post(url, headers, body)
                if ((r.first == 429 || r.first >= 500) && attempt < 2) {
                    Thread.sleep(1500L * (attempt + 1))
                    continue
                }
                return r
            } catch (e: java.io.IOException) {
                last = e
                if (attempt < 2) Thread.sleep(1500L * (attempt + 1))
            }
        }
        throw last ?: java.io.IOException("request failed")
    }

    fun call(
        kind: String, baseUrl: String, key: String, model: String,
        system: String, turns: List<Turn>, tools: JSONArray
    ): LlmReply {
        return try {
            if (kind == "anthropic") callAnthropic(baseUrl, key, model, system, turns, tools)
            else callOpenAi(baseUrl, key, model, system, turns, tools)
        } catch (e: Exception) {
            LlmReply("", emptyList(), "Network problem (slow or offline connection): ${e.message ?: e.javaClass.simpleName}. Everything except the AI still works offline.")
        }
    }

    // ----- Anthropic -----
    private fun callAnthropic(
        baseUrl: String, key: String, model: String, system: String, turns: List<Turn>, tools: JSONArray
    ): LlmReply {
        val msgs = JSONArray()
        for (t in turns) {
            when (t) {
                is UserTurn -> msgs.put(JSONObject().put("role", "user").put("content", t.text))
                is AssistTurn -> {
                    val blocks = JSONArray()
                    if (t.text.isNotBlank()) blocks.put(JSONObject().put("type", "text").put("text", t.text))
                    for (c in t.calls) {
                        blocks.put(
                            JSONObject().put("type", "tool_use").put("id", c.id)
                                .put("name", c.name).put("input", c.input)
                        )
                    }
                    msgs.put(JSONObject().put("role", "assistant").put("content", blocks))
                }
                is ResultTurn -> {
                    val blocks = JSONArray()
                    for ((id, out) in t.results) {
                        blocks.put(
                            JSONObject().put("type", "tool_result").put("tool_use_id", id).put("content", out)
                        )
                    }
                    msgs.put(JSONObject().put("role", "user").put("content", blocks))
                }
            }
        }
        val body = JSONObject().put("model", model).put("max_tokens", 4096)
            .put("system", system).put("messages", msgs)
        if (tools.length() > 0) body.put("tools", tools)
        val url = baseUrl.trimEnd('/') + "/v1/messages"
        val (code, txt) = postRetry(
            url, mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString()
        )
        if (code !in 200..299) return LlmReply("", emptyList(), friendly(code, txt))
        val arr = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        val calls = ArrayList<ToolCall>()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            when (b.optString("type")) {
                "text" -> sb.append(b.optString("text"))
                "tool_use" -> calls.add(
                    ToolCall(b.getString("id"), b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                )
            }
        }
        return LlmReply(sb.toString(), calls, null)
    }

    // ----- OpenAI-compatible (Gemini, Groq, OpenRouter, Ollama, ...) -----
    private fun callOpenAi(
        baseUrl: String, key: String, model: String, system: String, turns: List<Turn>, tools: JSONArray
    ): LlmReply {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        for (t in turns) {
            when (t) {
                is UserTurn -> msgs.put(JSONObject().put("role", "user").put("content", t.text))
                is AssistTurn -> {
                    val m = JSONObject().put("role", "assistant")
                    m.put("content", if (t.text.isEmpty()) JSONObject.NULL else t.text)
                    if (t.calls.isNotEmpty()) {
                        val arr = JSONArray()
                        for (c in t.calls) {
                            arr.put(
                                JSONObject().put("id", c.id).put("type", "function").put(
                                    "function",
                                    JSONObject().put("name", c.name).put("arguments", c.input.toString())
                                )
                            )
                        }
                        m.put("tool_calls", arr)
                    }
                    msgs.put(m)
                }
                is ResultTurn -> for ((id, out) in t.results) {
                    msgs.put(JSONObject().put("role", "tool").put("tool_call_id", id).put("content", out))
                }
            }
        }
        val body = JSONObject().put("model", model).put("messages", msgs).put("max_tokens", 4096)
        if (tools.length() > 0) {
            val arr = JSONArray()
            for (i in 0 until tools.length()) {
                val t = tools.getJSONObject(i)
                arr.put(
                    JSONObject().put("type", "function").put(
                        "function",
                        JSONObject().put("name", t.getString("name"))
                            .put("description", t.getString("description"))
                            .put("parameters", t.getJSONObject("input_schema"))
                    )
                )
            }
            body.put("tools", arr)
        }
        val headers = HashMap<String, String>()
        if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"
        val (code, txt) = postRetry(baseUrl.trimEnd('/') + "/chat/completions", headers, body.toString())
        if (code !in 200..299) return LlmReply("", emptyList(), friendly(code, txt))
        val msg = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val text = if (msg.isNull("content")) "" else msg.optString("content")
        val calls = ArrayList<ToolCall>()
        val tc = msg.optJSONArray("tool_calls")
        if (tc != null) {
            for (i in 0 until tc.length()) {
                val o = tc.getJSONObject(i)
                val f = o.getJSONObject("function")
                val args = try {
                    JSONObject(f.optString("arguments", "{}").ifBlank { "{}" })
                } catch (e: Exception) {
                    JSONObject()
                }
                val id = o.optString("id").ifBlank { "call_$i" + "_" + System.nanoTime() }
                calls.add(ToolCall(id, f.getString("name"), args))
            }
        }
        return LlmReply(text, calls, null)
    }
}
