package com.apkdebuglab

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Tools Claude can call to investigate and (with approval) edit the opened app. */
object Agent {
    const val SYSTEM = "You are an expert Android reverse-engineering and debugging agent inside an APK " +
        "inspector. The opened app is on disk in these folders: smali/<classesN>/ (disassembled dex, " +
        "editable), xml/ (decoded binary XML such as xml/AndroidManifest.xml and layouts; READ-ONLY), " +
        "xml/res_ids.txt (maps resource ids like 0x7f0b0012 to names such as id/login_button) and " +
        "xml/strings.txt (string resources), and files/ (raw files). Smali refers to resources by their " +
        "hex id, so map names to ids with res_ids.txt. When the user describes a feature in plain words (for " +
        "example 'block generator' or 'where scores are saved') call find_feature first; use describe_layout " +
        "to understand a screen. Work like a detective: use search_code, " +
        "read_file and list_dir to gather evidence before answering, follow call chains across files, and " +
        "cite locations as path:line so the user can tap them. To change code call propose_edit with an " +
        "exact, unique 'find' snippet and the replacement; keep edits minimal, explain the risk, and " +
        "remember that smali edits must keep register counts and syntax valid. When the user gives a change " +
        "command (for example 'make the generator create 10 blocks'), locate the code, read it, then propose " +
        "the edit. Never claim an edit was " +
        "applied unless the tool result says so. Be concise."

    private fun prop(type: String, desc: String): JSONObject =
        JSONObject().put("type", type).put("description", desc)

    private fun tool(name: String, desc: String, props: JSONObject, req: List<String>): JSONObject =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    val tools: JSONArray by lazy {
        JSONArray()
            .put(
                tool(
                    "search_code",
                    "Search all smali, decoded xml and text files. Plain text also matches the hex id of a resource with that name.",
                    JSONObject()
                        .put("query", prop("string", "text or regex to find"))
                        .put("regex", prop("boolean", "treat query as a regular expression"))
                        .put("file_types", prop("string", "comma separated extensions, e.g. smali,xml"))
                        .put("folder", prop("string", "only paths containing this folder or package")),
                    listOf("query")
                )
            )
            .put(
                tool(
                    "read_file",
                    "Read lines from a file (max 250 lines per call).",
                    JSONObject()
                        .put("path", prop("string", "path relative to the workspace, e.g. smali/classes/com/a/B.smali"))
                        .put("start_line", prop("integer", "first line, default 1"))
                        .put("end_line", prop("integer", "last line")),
                    listOf("path")
                )
            )
            .put(
                tool(
                    "list_dir",
                    "List files and folders in a directory of the workspace.",
                    JSONObject().put("path", prop("string", "directory path, empty for the root")),
                    emptyList()
                )
            )
            .put(
                tool(
                    "find_feature",
                    "Find code by describing what it does in plain words (e.g. 'block generator', 'login screen', 'save score'). Matches class, method, field, string and resource names across the whole app and follows resources to the code that uses them.",
                    JSONObject().put("description", prop("string", "plain-language description of the feature")),
                    listOf("description")
                )
            )
            .put(
                tool(
                    "describe_layout",
                    "Show a screen layout as an indented tree of views with ids, text and click handlers.",
                    JSONObject().put("name", prop("string", "layout name like layout/activity_main, or its path under xml/")),
                    listOf("name")
                )
            )
            .put(
                tool(
                    "propose_edit",
                    "Propose replacing an exact, unique snippet in a smali or text file. The user approves it first.",
                    JSONObject()
                        .put("path", prop("string", "file path (not under xml/)"))
                        .put("find", prop("string", "exact existing text, must occur exactly once"))
                        .put("replace", prop("string", "new text"))
                        .put("reason", prop("string", "why this change")),
                    listOf("path", "find", "replace", "reason")
                )
            )
    }

    private fun safeFile(ws: File, path: String): File? {
        val f = File(ws, path)
        val ok = try {
            f.canonicalPath.startsWith(ws.canonicalPath + File.separator)
        } catch (e: Exception) {
            false
        }
        return if (ok) f else null
    }

    private fun describe(n: UiNode, d: Int, sb: StringBuilder, vm: AppViewModel) {
        if (sb.length > 6000) return
        sb.append("  ".repeat(d)).append(n.tag.substringAfterLast('.'))
        n.attrs["android:id"]?.let { sb.append(" id=").append(it) }
        n.attrs["android:text"]?.let { sb.append(" text=\"").append(vm.resolveText(it).take(40)).append('"') }
        n.attrs["android:onClick"]?.let { sb.append(" onClick=").append(it) }
        sb.append("  (line ").append(n.line).append(")\n")
        for (c in n.children) describe(c, d + 1, sb, vm)
    }

    fun execute(vm: AppViewModel, name: String, input: JSONObject): String {
        val ws = vm.workspace ?: return "No app is open."
        when (name) {
            "search_code" -> {
                val q = input.optString("query")
                if (q.isBlank()) return "query is empty"
                val rx = input.optBoolean("regex", false)
                val re = try {
                    vm.buildRegex(q, rx, false)
                } catch (e: Exception) {
                    return "Invalid regex: ${e.message}"
                }
                val exts = input.optString("file_types").split(",", " ")
                    .map { it.trim().trimStart('.').lowercase() }.filter { it.isNotEmpty() }
                val hits = Searcher.search(vm.index, re, exts, input.optString("folder"), 60)
                vm.showHits(q, rx, hits)
                if (hits.isEmpty()) return "No matches. Try a shorter term, a regex, or search xml/res_ids.txt."
                val files = hits.map { it.path }.distinct().size
                return "${hits.size} matches in $files files:\n" +
                    hits.take(30).joinToString("\n") { "${it.path}:${it.line}: ${it.text.trim().take(160)}" }
            }
            "find_feature" -> {
                val d = input.optString("description")
                if (d.isBlank()) return "description is empty"
                val h = vm.featureHits(d)
                if (h.isEmpty()) {
                    return "No feature matches. Code may still be loading (${vm.dexDone}/${vm.dexTotal} dex). Try other words or search_code."
                }
                vm.showFeatureHits(d, h)
                return "${h.size} matches:\n" + h.take(35).joinToString("\n") { "${it.path}:${it.line}: ${it.text.take(140)}" }
            }
            "describe_layout" -> {
                val nm = input.optString("name")
                val rel = vm.layouts.firstOrNull {
                    it.first == nm || it.second == nm || it.first.endsWith("/" + nm.removePrefix("layout/"))
                }?.second ?: (if (nm.startsWith("xml/")) nm else null)
                if (rel == null) return "Layout not found. Known layouts: " + vm.layouts.take(40).joinToString { it.first }
                val f = safeFile(ws, rel)
                if (f == null || !f.isFile) return "Layout file missing"
                val tree = Preview.parseLayout(f.readText()) ?: return "Could not parse layout"
                val sb = StringBuilder()
                describe(tree, 0, sb, vm)
                return sb.toString().take(6000)
            }
            "read_file" -> {
                val path = input.optString("path")
                val f = safeFile(ws, path)
                if (f == null || !f.isFile) return "File not found: $path"
                if (!path.endsWith(".smali") && !Searcher.isText(f)) return "Binary file, cannot read as text."
                val lines = f.readLines()
                val start = input.optInt("start_line", 1).coerceAtLeast(1)
                if (start > lines.size) return "File has only ${lines.size} lines."
                val end = minOf(input.optInt("end_line", start + 119), start + 249, lines.size)
                val sb = StringBuilder("$path (${lines.size} lines)\n")
                for (i in start..end) sb.append(i).append("  ").append(lines[i - 1]).append('\n')
                return sb.toString()
            }
            "list_dir" -> {
                val d = safeFile(ws, input.optString("path")) ?: ws
                if (!d.isDirectory) return "Not a directory."
                val kids = d.listFiles()
                    ?.filter { !it.name.startsWith(".") && !it.name.startsWith("tmp_") }
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name })) ?: emptyList()
                return kids.take(200).joinToString("\n") {
                    if (it.isDirectory) it.name + "/" else it.name + " (" + sizeStr(it.length()) + ")"
                } + (if (kids.size > 200) "\n... ${kids.size - 200} more" else "")
            }
            "propose_edit" -> {
                val path = input.optString("path")
                val find = input.optString("find")
                val replace = input.optString("replace")
                val reason = input.optString("reason")
                if (path.startsWith("xml/")) {
                    return "Files under xml/ are read-only decoded views and cannot be rebuilt. Edit smali or files/ instead."
                }
                val f = safeFile(ws, path)
                if (f == null || !f.isFile) return "File not found: $path"
                if (find.isEmpty()) return "find must not be empty"
                val text = f.readText()
                val i = text.indexOf(find)
                if (i < 0) return "find text not found; it must match exactly, including whitespace."
                if (text.indexOf(find, i + 1) >= 0) return "find text occurs more than once; include more surrounding lines."
                val e = PendingEdit(path, find, replace, reason)
                return if (vm.autoApply) {
                    "Auto-apply result: " + vm.applyEdit(e)
                } else {
                    vm.pendingEdits.add(e)
                    "Queued for the user's approval. Do not assume it is applied."
                }
            }
        }
        return "Unknown tool: $name"
    }
}
