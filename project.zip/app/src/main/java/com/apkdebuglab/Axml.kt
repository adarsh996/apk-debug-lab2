package com.apkdebuglab

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Parsed resources.arsc: resource id -> "type/name", plus string values (text or file paths). */
class ResTable(
    val names: HashMap<Int, String>,
    val values: HashMap<Int, MutableList<String>>
) {
    val nameToId: HashMap<String, Int> by lazy {
        val m = HashMap<String, Int>()
        for ((k, v) in names) m[v] = k
        m
    }

    fun hex(id: Int): String = String.format("0x%08x", id)
    fun firstValue(id: Int): String? = values[id]?.firstOrNull()
    fun firstValue(name: String): String? = nameToId[name]?.let { firstValue(it) }
}

object Axml {
    private fun u16(b: ByteBuffer, o: Int): Int = b.getShort(o).toInt() and 0xFFFF
    private fun u8(b: ByteBuffer, o: Int): Int = b.get(o).toInt() and 0xFF
    private fun s(list: List<String>, i: Int): String = if (i < 0 || i >= list.size) "" else list[i]

    fun isBinaryXml(head: ByteArray): Boolean =
        head.size >= 4 && head[0].toInt() == 3 && head[1].toInt() == 0 &&
            head[2].toInt() == 8 && head[3].toInt() == 0

    private fun readPool(b: ByteBuffer, start: Int): List<String> {
        val headerSize = u16(b, start + 2)
        val count = b.getInt(start + 8)
        val flags = b.getInt(start + 16)
        val stringsStart = b.getInt(start + 20)
        val utf8 = (flags and 0x100) != 0
        val base = start + stringsStart
        val out = ArrayList<String>(maxOf(count, 0))
        for (i in 0 until count) {
            var p = base + b.getInt(start + headerSize + i * 4)
            if (utf8) {
                var l = u8(b, p); p += 1
                if ((l and 0x80) != 0) { l = ((l and 0x7F) shl 8) or u8(b, p); p += 1 }
                var bl = u8(b, p); p += 1
                if ((bl and 0x80) != 0) { bl = ((bl and 0x7F) shl 8) or u8(b, p); p += 1 }
                val bytes = ByteArray(bl)
                for (k in 0 until bl) bytes[k] = b.get(p + k)
                out.add(String(bytes, Charsets.UTF_8))
            } else {
                var l = u16(b, p); p += 2
                if ((l and 0x8000) != 0) { l = ((l and 0x7FFF) shl 16) or u16(b, p); p += 2 }
                val chars = CharArray(l) { u16(b, p + it * 2).toChar() }
                out.add(String(chars))
            }
        }
        return out
    }

    // ---------------- resources.arsc ----------------

    fun parseResTable(data: ByteArray): ResTable {
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val names = HashMap<Int, String>()
        val values = HashMap<Int, MutableList<String>>()
        var pos = u16(b, 2)
        var global: List<String> = emptyList()
        while (pos + 8 <= data.size) {
            val type = u16(b, pos)
            val size = b.getInt(pos + 4)
            if (size <= 0) break
            when (type) {
                0x0001 -> global = readPool(b, pos)
                0x0200 -> parsePackage(b, pos, size, global, names, values)
            }
            pos += size
        }
        return ResTable(names, values)
    }

    private fun parsePackage(
        b: ByteBuffer, start: Int, size: Int, global: List<String>,
        names: HashMap<Int, String>, values: HashMap<Int, MutableList<String>>
    ) {
        val hs = u16(b, start + 2)
        val pkgId = b.getInt(start + 8)
        val typeNames = readPool(b, start + b.getInt(start + 268))
        val keyNames = readPool(b, start + b.getInt(start + 276))
        var pos = start + hs
        val end = minOf(start + size, b.limit())
        while (pos + 8 <= end) {
            val type = u16(b, pos)
            val chs = u16(b, pos + 2)
            val csize = b.getInt(pos + 4)
            if (csize <= 0) break
            if (type == 0x0201) parseType(b, pos, chs, pkgId, typeNames, keyNames, global, names, values)
            pos += csize
        }
    }

    private fun parseType(
        b: ByteBuffer, pos: Int, chs: Int, pkgId: Int,
        typeNames: List<String>, keyNames: List<String>, global: List<String>,
        names: HashMap<Int, String>, values: HashMap<Int, MutableList<String>>
    ) {
        val typeId = u8(b, pos + 8)
        val flags = u8(b, pos + 9)
        val entryCount = b.getInt(pos + 12)
        val entriesStart = b.getInt(pos + 16)
        val offsetsStart = pos + chs
        val typeName = typeNames.getOrNull(typeId - 1) ?: "type$typeId"
        for (i in 0 until entryCount) {
            var entryIdx = i
            val off: Long
            if ((flags and 1) != 0) {
                val v = b.getInt(offsetsStart + i * 4)
                entryIdx = v and 0xFFFF
                off = ((v ushr 16) and 0xFFFF).toLong() * 4
            } else if ((flags and 2) != 0) {
                val v = u16(b, offsetsStart + i * 2)
                if (v == 0xFFFF) continue
                off = v.toLong() * 4
            } else {
                val v = b.getInt(offsetsStart + i * 4)
                if (v == -1) continue
                off = v.toLong() and 0xFFFFFFFFL
            }
            val e = pos + entriesStart + off.toInt()
            if (e < 0 || e + 8 > b.limit()) continue
            val eflags = u16(b, e + 2)
            val key = b.getInt(e + 4)
            val id = (pkgId shl 24) or (typeId shl 16) or entryIdx
            if (!names.containsKey(id)) names[id] = typeName + "/" + (keyNames.getOrNull(key) ?: "?")
            if ((eflags and 1) == 0 && e + 16 <= b.limit()) {
                val dt = u8(b, e + 11)
                val dv = b.getInt(e + 12)
                if (dt == 0x03) {
                    val str = global.getOrNull(dv)
                    if (str != null) values.getOrPut(id) { ArrayList() }.add(str)
                }
            }
        }
    }

    // ---------------- binary XML ----------------

    private val RADIX = floatArrayOf(0.00390625f, 3.051758E-5f, 1.192093E-7f, 4.656613E-10f)
    private val UNITS = arrayOf("px", "dip", "sp", "pt", "in", "mm")

    private fun fmtF(v: Float): String =
        if (v == Math.floor(v.toDouble()).toFloat()) v.toInt().toString() else v.toString()

    private fun esc(t: String): String =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun ref(id: Int, res: ResTable?, prefix: String): String {
        val n = res?.names?.get(id)
        if (n != null) return prefix + n
        if (id == 0) return "@null"
        return prefix + "0x" + Integer.toHexString(id)
    }

    private fun value(dt: Int, dv: Int, raw: Int, strings: List<String>, res: ResTable?): String = when (dt) {
        0x03 -> s(strings, if (raw >= 0) raw else dv)
        0x01 -> ref(dv, res, "@")
        0x02 -> ref(dv, res, "?")
        0x04 -> java.lang.Float.intBitsToFloat(dv).toString()
        0x05 -> fmtF((dv and -256).toFloat() * RADIX[(dv shr 4) and 3]) + (UNITS.getOrNull(dv and 0xF) ?: "")
        0x06 -> fmtF((dv and -256).toFloat() * RADIX[(dv shr 4) and 3] * 100) + "%"
        0x10 -> dv.toString()
        0x11 -> "0x" + Integer.toHexString(dv)
        0x12 -> if (dv != 0) "true" else "false"
        in 0x1c..0x1f -> "#" + String.format("%08x", dv)
        else -> if (raw >= 0) s(strings, raw) else "0x" + Integer.toHexString(dv)
    }

    /** Binary AndroidManifest / layout XML -> readable text, one element per line. */
    fun decode(data: ByteArray, res: ResTable?): String {
        if (!isBinaryXml(data)) throw IllegalArgumentException("not binary xml")
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        var strings: List<String> = emptyList()
        var resIds = IntArray(0)
        val prefixes = HashMap<String, String>()
        val pendingNs = ArrayList<Pair<String, String>>()
        val sb = StringBuilder()
        var indent = 0
        var pos = u16(b, 2)
        val total = minOf(b.getInt(4), data.size)
        while (pos + 8 <= total) {
            val type = u16(b, pos)
            val size = b.getInt(pos + 4)
            if (size <= 0) break
            when (type) {
                0x0001 -> strings = readPool(b, pos)
                0x0180 -> resIds = IntArray(maxOf(0, (size - 8) / 4)) { b.getInt(pos + 8 + it * 4) }
                0x0100 -> {
                    val prefix = s(strings, b.getInt(pos + 16))
                    val uri = s(strings, b.getInt(pos + 20))
                    prefixes[uri] = prefix
                    pendingNs.add(prefix to uri)
                }
                0x0102 -> {
                    val name = s(strings, b.getInt(pos + 20))
                    val attrStart = u16(b, pos + 24)
                    val attrSize = u16(b, pos + 26)
                    val attrCount = u16(b, pos + 28)
                    sb.append("  ".repeat(indent)).append('<').append(name)
                    for ((p, u) in pendingNs) {
                        sb.append(" xmlns:").append(p).append("=\"").append(esc(u)).append('"')
                    }
                    pendingNs.clear()
                    var ap = pos + 16 + attrStart
                    for (k in 0 until attrCount) {
                        val ns = b.getInt(ap)
                        val an = b.getInt(ap + 4)
                        val raw = b.getInt(ap + 8)
                        val dt = u8(b, ap + 15)
                        val dv = b.getInt(ap + 16)
                        val pre = if (ns >= 0) prefixes[s(strings, ns)] else null
                        var aname = s(strings, an)
                        if (aname.isEmpty()) aname = "attr_" + Integer.toHexString(resIds.getOrElse(an) { an })
                        sb.append(' ')
                        if (!pre.isNullOrEmpty()) sb.append(pre).append(':')
                        sb.append(aname).append("=\"").append(esc(value(dt, dv, raw, strings, res))).append('"')
                        ap += if (attrSize >= 20) attrSize else 20
                    }
                    sb.append(">\n")
                    indent++
                }
                0x0103 -> {
                    indent = maxOf(0, indent - 1)
                    sb.append("  ".repeat(indent)).append("</").append(s(strings, b.getInt(pos + 20))).append(">\n")
                }
                0x0104 -> {
                    val t = s(strings, b.getInt(pos + 16)).trim()
                    if (t.isNotEmpty()) sb.append("  ".repeat(indent)).append(esc(t)).append('\n')
                }
            }
            pos += size
        }
        return sb.toString()
    }
}
