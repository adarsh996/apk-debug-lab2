package com.apkdebuglab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(e.stackTraceToString().take(4000))
            } catch (x: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { AppRoot(vm) }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        vm.flushState()
    }
}
