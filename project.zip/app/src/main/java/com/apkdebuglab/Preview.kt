package com.apkdebuglab

import android.util.Xml
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.Card
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.Arrangement as Arr
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

class UiNode(val tag: String, val attrs: Map<String, String>, val line: Int) {
    val children = ArrayList<UiNode>()
}

data class ActInfo(val name: String, val launcher: Boolean)

data class ManifestInfo(
    val pkg: String, val label: String, val versionName: String,
    val minSdk: String, val targetSdk: String, val perms: Int,
    val services: Int, val receivers: Int, val iconRef: String?, val activities: List<ActInfo>
)

object Preview {
    fun parseLayout(text: String): UiNode? {
        return try {
            val p = Xml.newPullParser()
            p.setInput(StringReader(text))
            val stack = ArrayList<UiNode>()
            var root: UiNode? = null
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val m = LinkedHashMap<String, String>()
                    for (i in 0 until p.attributeCount) m[p.getAttributeName(i)] = p.getAttributeValue(i)
                    val n = UiNode(p.name, m, p.lineNumber)
                    if (stack.isEmpty()) root = n else stack[stack.size - 1].children.add(n)
                    stack.add(n)
                } else if (ev == XmlPullParser.END_TAG) {
                    if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                }
                ev = p.next()
            }
            root
        } catch (e: Exception) {
            null
        }
    }

    private fun attr(p: XmlPullParser, key: String): String? {
        for (i in 0 until p.attributeCount) if (p.getAttributeName(i) == key) return p.getAttributeValue(i)
        return null
    }

    fun parseManifest(text: String, resolve: (String) -> String): ManifestInfo? {
        val p = Xml.newPullParser()
        p.setInput(StringReader(text))
        var pkg = ""
        var ver = ""
        var minSdk = "?"
        var target = "?"
        var perms = 0
        var services = 0
        var receivers = 0
        var label = ""
        var icon: String? = null
        val acts = ArrayList<String>()
        val launcher = HashSet<Int>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "manifest" -> {
                        pkg = attr(p, "package") ?: ""
                        ver = attr(p, "android:versionName") ?: ""
                    }
                    "uses-sdk" -> {
                        minSdk = attr(p, "android:minSdkVersion") ?: "?"
                        target = attr(p, "android:targetSdkVersion") ?: "?"
                    }
                    "uses-permission" -> perms++
                    "service" -> services++
                    "receiver" -> receivers++
                    "application" -> {
                        label = resolve(attr(p, "android:label") ?: "")
                        icon = attr(p, "android:icon")
                    }
                    "activity", "activity-alias" -> acts.add(attr(p, "android:name") ?: attr(p, "android:targetActivity") ?: "?")
                    "category" -> if ((attr(p, "android:name") ?: "").contains("LAUNCHER") && acts.isNotEmpty()) {
                        launcher.add(acts.size - 1)
                    }
                }
            }
            ev = p.next()
        }
        if (pkg.isEmpty() && acts.isEmpty()) return null
        fun full(n: String): String = when {
            n.startsWith(".") -> pkg + n
            !n.contains('.') -> "$pkg.$n"
            else -> n
        }
        return ManifestInfo(
            pkg, label, ver, minSdk, target, perms, services, receivers, icon,
            acts.mapIndexed { i, n -> ActInfo(full(n), i in launcher) }.distinctBy { it.name }
        )
    }
}

private val Mono = FontFamily.Monospace

// ---------------- Preview tab ----------------

@Composable
fun PreviewTab(vm: AppViewModel) {
    if (vm.previewLayout != null) LayoutPreview(vm) else Overview(vm)
}

@Composable
fun Overview(vm: AppViewModel) {
    val info = vm.info
    var filter by remember { mutableStateOf("") }
    val layoutList = vm.layouts.filter { filter.isBlank() || it.first.contains(filter, true) }.take(60)
    LazyColumn(
        Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val bmp = vm.iconBitmap
                if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.size(56.dp))
                Column {
                    Text(
                        (info?.label?.ifBlank { null } ?: vm.appName),
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (info != null) {
                        Text(info.pkg, fontSize = 12.sp, color = Color.Gray)
                        Text(
                            "v${info.versionName} · SDK ${info.minSdk}/${info.targetSdk} · ${info.perms} permissions · " +
                                "${info.services} services · ${info.receivers} receivers",
                            fontSize = 11.sp, color = Color.Gray
                        )
                    }
                }
            }
        }
        if (vm.bgBusy) {
            item {
                Text(
                    "Reading the app's code in the background (${vm.dexDone}/${vm.dexTotal}). Search and code links fill in as it goes.",
                    fontSize = 12.sp, color = Color(0xFF1565C0)
                )
            }
        }
        item { Text("Screens", style = MaterialTheme.typography.titleSmall) }
        item {
            Text(
                "Tap Preview to draw a screen's layout as a wireframe, then tap any block to see the code behind it.",
                fontSize = 12.sp, color = Color.Gray
            )
        }
        if (info == null || info.activities.isEmpty()) {
            item { Text("No screens found in the manifest.") }
        } else {
            items(info.activities, key = { it.name }) { a ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name.substringAfterLast('.'), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(a.name + if (a.launcher) "  (opens first)" else "", fontSize = 10.sp, color = Color.Gray)
                    }
                    TextButton(onClick = { vm.openActivity(a.name) }) { Text("Preview") }
                    TextButton(onClick = { vm.openClass(a.name) }) { Text("Code") }
                }
            }
        }
        if (vm.candidates.size > 1) {
            item { Text("Layouts used by ${vm.candName}", style = MaterialTheme.typography.titleSmall) }
            items(vm.candidates, key = { "c" + it.second }) { (name, rel) ->
                TextButton(onClick = { vm.showLayout(rel) }) { Text(name) }
            }
        }
        item { Text("All layouts (${vm.layouts.size})", style = MaterialTheme.typography.titleSmall) }
        item {
            OutlinedTextField(
                value = filter, onValueChange = { filter = it }, singleLine = true,
                label = { Text("Filter layouts") }, modifier = Modifier.fillMaxWidth()
            )
        }
        items(layoutList, key = { "l" + it.second }) { (name, rel) ->
            TextButton(onClick = { vm.showLayout(rel) }) { Text(name, fontSize = 13.sp) }
        }
    }
}

@Composable
fun LayoutPreview(vm: AppViewModel) {
    val rel = vm.previewLayout ?: return
    if (vm.showSheet) {
        ElementSheet(vm)
        return
    }
    val tree = vm.previewTree
    val sel = vm.selNode
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            TextButton(onClick = { vm.closePreview() }) { Text("‹ Back") }
            Text(rel.removePrefix("xml/"), fontSize = 11.sp, maxLines = 2, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.open(rel, sel?.line ?: 0) }) { Text("Code") }
        }
        Text(
            "Tap a block for quick info. Double-tap anything to see its code, methods and related files.",
            fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 12.dp)
        )
        Box(
            Modifier.weight(1f).fillMaxWidth().background(Color(0xFFF2F2F2)).padding(6.dp)
                .pointerInput(rel) { detectTapGestures(onDoubleTap = { vm.inspectLayout() }) }
        ) {
            if (tree == null) {
                Text("This layout can't be drawn as a wireframe. Use Code to read it.")
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    NodeView(tree, sel, vm::resolveText, { vm.inspectNode(it, false) }, { vm.inspectNode(it, true) }, 0)
                }
            }
        }
        Inspector(vm, Modifier.weight(1f))
    }
}

@Composable
fun ElementSheet(vm: AppViewModel) {
    var instruction by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            TextButton(onClick = { vm.showSheet = false }) { Text("‹ Preview") }
            Text(vm.sheetTitle, fontSize = 12.sp, maxLines = 2, modifier = Modifier.weight(1f))
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            if (vm.sheetBlocks.isEmpty()) {
                item {
                    Text(
                        "No code found yet. If the app is still reading its code (see the bar at the top), try again in a moment.",
                        color = Color.Gray, modifier = Modifier.padding(12.dp)
                    )
                }
            }
            items(vm.sheetBlocks) { (head, code) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(head, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = Mono, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                vm.open(head.substringBeforeLast(':'), head.substringAfterLast(':').toIntOrNull() ?: 0)
                            }) { Text("Open") }
                        }
                        Text(highlight(code, vm.inspectRe ?: vm.hlRe), fontFamily = Mono, fontSize = 11.sp)
                    }
                }
            }
            if (vm.sheetFiles.isNotEmpty()) {
                item { Text("Related files", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
                items(vm.sheetFiles) { p ->
                    TextButton(onClick = { vm.open(p) }) { Text(p, fontSize = 11.sp, fontFamily = Mono) }
                }
            }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arr.spacedBy(8.dp)) {
            OutlinedTextField(
                value = instruction, onValueChange = { instruction = it },
                label = { Text("Tell the AI what to change here") }, maxLines = 3, modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { vm.editWithAI(instruction); instruction = "" },
                enabled = !vm.busy && instruction.isNotBlank()
            ) { Text("Edit") }
        }
    }
}

private fun isVertical(o: String?): Boolean = o == "1" || o == "0x1" || o == "vertical"

@Composable
fun NodeView(
    n: UiNode, sel: UiNode?, resolve: (String) -> String,
    onTap: (UiNode) -> Unit, onDouble: (UiNode) -> Unit, depth: Int
) {
    val isSel = n === sel
    val short = n.tag.substringAfterLast('.')
    val idv = n.attrs["android:id"]?.substringAfter('/')
    val txt = (n.attrs["android:text"] ?: n.attrs["android:hint"])?.let { resolve(it) }
    val frame = Modifier
        .fillMaxWidth()
        .padding(2.dp)
        .border(if (isSel) 2.dp else 1.dp, if (isSel) Color(0xFFD81B60) else Color(0xFF9E9E9E), RoundedCornerShape(4.dp))
        .background(if (isSel) Color(0x22D81B60) else Color.White)
        .pointerInput(n) { detectTapGestures(onTap = { onTap(n) }, onDoubleTap = { onDouble(n) }) }
        .padding(4.dp)
    Column(frame) {
        Text(short + (if (idv != null) "  #$idv" else ""), fontSize = 9.sp, color = Color.Gray)
        if (n.children.isEmpty()) {
            when {
                txt != null -> Text(txt, fontSize = 13.sp)
                short.contains("Image") -> Text("▣ image", fontSize = 12.sp, color = Color.Gray)
                else -> Text(" ", fontSize = 12.sp)
            }
        } else if (depth > 12) {
            Text("…", fontSize = 12.sp)
        } else {
            if (txt != null) Text(txt, fontSize = 13.sp)
            val vertical = !short.endsWith("LinearLayout") || isVertical(n.attrs["android:orientation"])
            if (vertical) {
                for (c in n.children) NodeView(c, sel, resolve, onTap, onDouble, depth + 1)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (c in n.children) {
                        Box(Modifier.weight(1f)) { NodeView(c, sel, resolve, onTap, onDouble, depth + 1) }
                    }
                }
            }
        }
    }
}

@Composable
fun Inspector(vm: AppViewModel, modifier: Modifier) {
    val n = vm.selNode
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        if (n == null) {
            item {
                Text(
                    "Tap any block in the preview to see its code, where it lives, and related logic.",
                    color = Color.Gray, modifier = Modifier.padding(12.dp)
                )
            }
        } else {
            item {
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(
                        n.tag.substringAfterLast('.') + (n.attrs["android:id"]?.let { "  $it" } ?: ""),
                        fontWeight = FontWeight.Bold
                    )
                    n.attrs["android:text"]?.let { Text("text: " + vm.resolveText(it), fontSize = 12.sp) }
                    n.attrs["android:onClick"]?.let { Text("onClick: $it", fontSize = 12.sp) }
                    Text("layout line ${n.line}", fontSize = 11.sp, color = Color.Gray)
                    Row {
                        TextButton(onClick = { vm.inspectNode(n, true) }) { Text("Show code") }
                        TextButton(onClick = { vm.previewLayout?.let { vm.open(it, n.line) } }) { Text("Layout") }
                        TextButton(onClick = { vm.askAboutElement(n) }) { Text("Ask AI") }
                    }
                }
            }
            if (vm.inspectHits.isEmpty()) {
                item { Text(if (vm.busy) "Searching…" else "No code references found.", color = Color.Gray) }
            }
            itemsIndexed(vm.inspectHits) { i, h ->
                Column {
                    if (i == 0 || vm.inspectHits[i - 1].path != h.path) {
                        Text(
                            h.path, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = Mono,
                            modifier = Modifier.fillMaxWidth().clickable { vm.open(h.path) }.padding(vertical = 8.dp)
                        )
                    }
                    HitCard(vm, h, vm.inspectRe ?: vm.hlRe)
                }
            }
        }
    }
}
