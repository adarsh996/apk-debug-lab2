package com.apkdebuglab

import org.jf.baksmali.Baksmali
import org.jf.baksmali.BaksmaliOptions
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.iface.ClassDef
import org.jf.dexlib2.iface.DexFile
import org.jf.smali.Smali
import org.jf.smali.SmaliOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.PrintStream

/** A view of a dex file that only exposes some classes (no copying, so it stays fast and light). */
private class FilteredDex(private val base: DexFile, private val keep: Set<ClassDef>) : DexFile {
    override fun getClasses(): Set<ClassDef> = keep
    override fun getOpcodes(): Opcodes = base.opcodes
}

object DexTools {
    // Big third-party libraries: skipped by default so reading the app's own code is much faster.
    private val LIBS = listOf(
        "Landroidx/", "Landroid/support/", "Lkotlin/", "Lkotlinx/", "Lcom/google/android/gms/",
        "Lcom/google/firebase/", "Lcom/google/android/material/", "Lcom/google/common/",
        "Lcom/google/protobuf/", "Lcom/google/gson/", "Lokhttp3/", "Lokio/", "Lretrofit2/",
        "Lcom/squareup/", "Lcom/bumptech/", "Lorg/jetbrains/", "Ldagger/", "Lio/reactivex/",
        "Lcom/facebook/", "Lcom/airbnb/", "Lorg/apache/", "Lcom/fasterxml/", "Lj$/", "Lcom/unity3d/",
        "Lcom/applovin/", "Lcom/ironsource/", "Lcom/vungle/", "Lcom/chartboost/", "Lcom/mbridge/"
    )

    /** dex -> .smali files (one per class) under [out]. */
    fun disassemble(dex: File, out: File, skipLibs: Boolean) {
        out.mkdirs()
        var dexFile: DexFile = DexFileFactory.loadDexFile(dex, Opcodes.getDefault())
        if (skipLibs) {
            val keep = HashSet<ClassDef>()
            for (c in dexFile.classes) {
                val t: String = c.type
                if (LIBS.none { t.startsWith(it) }) keep.add(c)
            }
            dexFile = FilteredDex(dexFile, keep)
        }
        val options = BaksmaliOptions()
        Baksmali.disassembleDexFile(dexFile, out, 3, options)
    }

    /** Assemble just these edited .smali files into a patch dex. */
    fun assembleFiles(files: List<File>, outDex: File) {
        val options = SmaliOptions()
        options.apiLevel = 29
        options.outputDexFile = outDex.absolutePath
        val oldErr = System.err
        val buf = ByteArrayOutputStream()
        System.setErr(PrintStream(buf, true))
        val ok = try {
            Smali.assemble(options, files.map { it.absolutePath })
        } finally {
            System.setErr(oldErr)
        }
        if (!ok) {
            throw IllegalStateException("smali error: " + buf.toString().take(1200))
        }
    }
}
