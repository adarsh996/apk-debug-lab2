package com.apkdebuglab

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.android.apksig.ApkSigner
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Collections
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

private fun ByteBuffer.s(v: Int): ByteBuffer = putShort(v.toShort())
private fun ByteBuffer.i(v: Long): ByteBuffer = putInt(v.toInt())

/** Minimal zip writer that can align stored entries (needed for resources.arsc and .so files). */
class ZipWriter(file: File) : Closeable {
    private class Ent(
        val name: ByteArray, val method: Int, val crc: Long,
        val csize: Long, val usize: Long, val offset: Long
    )

    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    private var pos = 0L
    private val ents = ArrayList<Ent>()

    private fun deflate(data: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream(maxOf(32, data.size / 2))
        val d = Deflater(Deflater.BEST_SPEED, true)
        DeflaterOutputStream(bos, d).use { it.write(data) }
        d.end()
        return bos.toByteArray()
    }

    fun add(name: String, data: ByteArray, stored: Boolean, align: Int) {
        val nb = name.toByteArray(Charsets.UTF_8)
        val crc = CRC32().also { it.update(data) }.value
        val payload = if (stored) data else deflate(data)
        val method = if (stored) 0 else 8
        val dataStart = pos + 30 + nb.size
        val pad = if (stored && align > 1) ((align - (dataStart % align)) % align).toInt() else 0
        val h = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN)
        h.i(0x04034b50L); h.s(20); h.s(0x0800); h.s(method); h.s(0); h.s(33)
        h.i(crc); h.i(payload.size.toLong()); h.i(data.size.toLong()); h.s(nb.size); h.s(pad)
        val start = pos
        out.write(h.array())
        out.write(nb)
        if (pad > 0) out.write(ByteArray(pad))
        out.write(payload)
        pos += 30L + nb.size + pad + payload.size
        ents.add(Ent(nb, method, crc, payload.size.toLong(), data.size.toLong(), start))
    }

    override fun close() {
        val cdStart = pos
        for (e in ents) {
            val c = ByteBuffer.allocate(46 + e.name.size).order(ByteOrder.LITTLE_ENDIAN)
            c.i(0x02014b50L); c.s(20); c.s(20); c.s(0x0800); c.s(e.method); c.s(0); c.s(33)
            c.i(e.crc); c.i(e.csize); c.i(e.usize)
            c.s(e.name.size); c.s(0); c.s(0); c.s(0); c.s(0); c.i(0); c.i(e.offset)
            c.put(e.name)
            out.write(c.array())
            pos += c.capacity()
        }
        val cdSize = pos - cdStart
        val z = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN)
        z.i(0x06054b50L); z.s(0); z.s(0); z.s(ents.size); z.s(ents.size)
        z.i(cdSize); z.i(cdStart); z.s(0)
        out.write(z.array())
        out.close()
    }
}

object ApkTools {
    fun unzip(apk: File, outDir: File, storedList: File) {
        outDir.deleteRecursively()
        outDir.mkdirs()
        val root = outDir.canonicalPath + File.separator
        val stored = StringBuilder()
        ZipFile(apk).use { zf ->
            for (e in Collections.list(zf.entries())) {
                if (e.isDirectory) continue
                val target = File(outDir, e.name)
                if (!target.canonicalPath.startsWith(root)) continue
                target.parentFile?.mkdirs()
                zf.getInputStream(e).use { i -> target.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                if (e.method == ZipEntry.STORED) stored.append(e.name).append('\n')
            }
        }
        storedList.writeText(stored.toString())
    }

    /**
     * Repacks [files]. If [patchDex] is given (the reassembled edited classes), it becomes classes.dex and every
     * original dex shifts up by one, so the edited classes override the originals.
     */
    fun repack(files: File, storedList: File, out: File, patchDex: File?) {
        val stored: Set<String> =
            if (storedList.exists()) storedList.readLines().toHashSet() else emptySet()
        out.delete()
        val dexRe = Regex("classes(\\d*)\\.dex")
        val all = files.walkTopDown()
            .filter { it.isFile }
            .map { it to it.relativeTo(files).path.replace(File.separatorChar, '/') }
            .sortedBy { it.second }
            .toList()
        ZipWriter(out).use { zw ->
            if (patchDex != null) zw.add("classes.dex", patchDex.readBytes(), false, 1)
            for ((f, name) in all) {
                if (name.startsWith("META-INF/") &&
                    (name.endsWith(".SF") || name.endsWith(".RSA") || name.endsWith(".DSA") ||
                        name.endsWith(".EC") || name == "META-INF/MANIFEST.MF")
                ) continue
                var entry = name
                if (patchDex != null) {
                    val m = dexRe.matchEntire(name)
                    if (m != null) {
                        val idx = m.groupValues[1].ifEmpty { "1" }.toInt()
                        entry = "classes" + (idx + 1) + ".dex"
                    }
                }
                val isStored = name == "resources.arsc" || name in stored
                val align = if (isStored) (if (name.endsWith(".so")) 4096 else 4) else 1
                zw.add(entry, f.readBytes(), isStored, align)
            }
        }
    }

    fun sign(ctx: Context, input: File, output: File) {
        val pw = "android".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("debug.keystore").use { ks.load(it, pw) }
        val alias = ks.aliases().nextElement()
        val key = ks.getKey(alias, pw) as PrivateKey
        val cert = ks.getCertificate(alias) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("edited", key, listOf(cert)).build()
        output.delete()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setMinSdkVersion(24)
            .build()
            .sign()
    }

    fun installIntent(ctx: Context, apk: File): Intent {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
        return Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
