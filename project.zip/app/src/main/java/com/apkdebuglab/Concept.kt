package com.apkdebuglab

import java.io.File
import kotlin.math.ln

class IntList {
    var a = IntArray(4)
    var n = 0
    fun add(v: Int) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n++] = v
    }
}

/** kind: c class, m method, f field, s string literal, r resource, l layout. */
class CEntry(val kind: Char, val path: String, val line: Int, val label: String, val extra: String)

object Concept {
    private val STOP = setOf(
        "the", "and", "where", "what", "how", "why", "does", "this", "that", "with", "from", "find",
        "which", "into", "when", "your", "about", "there", "have", "are", "can", "for", "use", "used",
        "using", "works", "work", "please", "give", "tell", "any", "all", "app", "feature", "function",
        "method", "class", "code", "logic", "related", "something", "thing", "things", "screen", "its", "is", "in", "of", "to", "me"
    )

    private val SYN = mapOf(
        "create" to listOf("generate", "build", "make", "new", "add"),
        "generate" to listOf("create", "build", "make", "produce"),
        "delete" to listOf("remove", "clear", "erase", "destroy"),
        "remove" to listOf("delete", "clear"),
        "show" to listOf("display", "render", "draw", "present"),
        "login" to listOf("signin", "auth", "authenticate"),
        "logout" to listOf("signout"),
        "button" to listOf("btn"),
        "image" to listOf("img", "picture", "photo", "bitmap", "icon"),
        "download" to listOf("fetch", "load"),
        "save" to listOf("store", "persist", "write", "cache"),
        "send" to listOf("post", "submit", "upload"),
        "payment" to listOf("pay", "purchase", "billing", "checkout"),
        "ads" to listOf("ad", "advert", "banner", "interstitial"),
        "ad" to listOf("ads", "advert", "banner"),
        "settings" to listOf("setting", "preference", "config"),
        "notification" to listOf("notify", "push", "alert"),
        "user" to listOf("account", "profile", "member"),
        "search" to listOf("find", "query", "filter"),
        "list" to listOf("recycler", "adapter"),
        "timer" to listOf("countdown", "clock", "schedule"),
        "music" to listOf("audio", "sound", "player", "song"),
        "video" to listOf("player", "media", "stream"),
        "camera" to listOf("photo", "capture", "preview"),
        "map" to listOf("location", "gps", "marker"),
        "share" to listOf("send", "intent"),
        "database" to listOf("db", "sqlite", "room", "dao", "table"),
        "score" to listOf("point", "level", "rank"),
        "game" to listOf("play", "level", "score")
    )

    /** Splits camelCase, snake_case and paths into lowercase words. */
    fun words(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var prev = ' '
        for (c in s) {
            if (!c.isLetterOrDigit()) {
                if (sb.length >= 2) out.add(sb.toString().lowercase())
                sb.setLength(0)
                prev = ' '
                continue
            }
            if (sb.isNotEmpty() && c.isUpperCase() && prev.isLowerCase()) {
                if (sb.length >= 2) out.add(sb.toString().lowercase())
                sb.setLength(0)
            }
            sb.append(c)
            prev = c
        }
        if (sb.length >= 2) out.add(sb.toString().lowercase())
        return out
    }

    fun stem(w0: String): String {
        var w = w0
        if (w.length > 4 && w.endsWith("ies")) w = w.dropLast(3) + "y"
        else if (w.length > 3 && w.endsWith("s") && !w.endsWith("ss")) w = w.dropLast(1)
        return if (w.length > 6) w.take(6) else w
    }

    fun primary(q: String): List<String> =
        words(q).filter { it !in STOP }.map { stem(it) }.distinct()

    /** One group per query word: its stem plus the stems of its synonyms. */
    fun queryGroups(q: String): List<List<String>> {
        val out = ArrayList<List<String>>()
        for (w in words(q)) {
            if (w in STOP) continue
            val g = ArrayList<String>()
            g.add(stem(w))
            SYN[w]?.forEach { g.add(stem(it)) }
            out.add(g.distinct())
        }
        return out
    }

    fun highlight(q: String): Regex? {
        val stems = primary(q).filter { it.length >= 3 }
        if (stems.isEmpty()) return null
        return Regex(stems.joinToString("|") { Regex.escape(it) }, RegexOption.IGNORE_CASE)
    }

    fun display(e: CEntry): String = when (e.kind) {
        'c' -> "class " + e.label.replace('/', '.')
        'm' -> "method " + e.label.substringBefore(" @ ") + "() in " + e.label.substringAfter(" @ ")
        'f' -> "field " + e.label.substringBefore(" @ ") + " in " + e.label.substringAfter(" @ ")
        's' -> "text \"" + e.label.substringBefore(" @ ") + "\" in " + e.label.substringAfter(" @ ")
        'l' -> "layout " + e.label
        else -> "resource " + e.label
    }

    private fun weight(k: Char): Float = when (k) {
        'c' -> 1.4f
        'l' -> 1.3f
        'm' -> 1.2f
        'r' -> 1.1f
        'f' -> 0.9f
        else -> 1.0f
    }

    // -------- building entries --------

    fun scanSmali(ws: File, dir: File): List<CEntry> {
        val out = ArrayList<CEntry>()
        for (f in dir.walkTopDown()) {
            if (!f.isFile || !f.name.endsWith(".smali")) continue
            val rel = f.relativeTo(ws).path.replace('\\', '/')
            var cls = f.nameWithoutExtension
            var strings = 0
            var n = 0
            try {
                f.bufferedReader().useLines { seq ->
                    for (line in seq) {
                        n++
                        if (line.startsWith(".class")) {
                            val d = line.substringAfterLast(' ').removePrefix("L").removeSuffix(";")
                            cls = d.substringAfterLast('/')
                            out.add(CEntry('c', rel, n, d, ""))
                        } else if (line.startsWith(".method")) {
                            val name = line.substringBefore('(').substringAfterLast(' ')
                            if (name.isNotEmpty() && name != "<init>" && name != "<clinit>") {
                                out.add(CEntry('m', rel, n, "$name @ $cls", ""))
                            }
                        } else if (line.startsWith(".field")) {
                            val name = line.substringBefore(':').substringAfterLast(' ')
                            if (name.isNotEmpty()) out.add(CEntry('f', rel, n, "$name @ $cls", ""))
                        } else if (strings < 25) {
                            val t = line.trimStart()
                            if (t.startsWith("const-string")) {
                                val q1 = t.indexOf('"')
                                val q2 = t.lastIndexOf('"')
                                if (q1 >= 0 && q2 - q1 in 4..80) {
                                    val s = t.substring(q1 + 1, q2)
                                    if (s.any { it.isLetter() }) {
                                        strings++
                                        out.add(CEntry('s', rel, n, "$s @ $cls", ""))
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }
        return out
    }

    /** Writes xml/res_ids.txt and xml/strings.txt and returns searchable resource entries. */
    fun writeRes(ws: File, t: ResTable): List<CEntry> {
        val dir = File(ws, "xml")
        dir.mkdirs()
        val keys = t.names.keys.sorted()
        val out = ArrayList<CEntry>()
        File(dir, "res_ids.txt").bufferedWriter().use { w ->
            for (k in keys) w.append(t.hex(k)).append(' ').append(t.names[k]).append('\n')
        }
        var ln = 0
        File(dir, "strings.txt").bufferedWriter().use { w ->
            for (k in keys) {
                val nm = t.names[k] ?: continue
                if (!nm.startsWith("string/")) continue
                val v = t.firstValue(k) ?: continue
                ln++
                w.append(t.hex(k)).append(' ').append(nm).append(" = ").append(v.replace("\n", "\\n")).append('\n')
                out.add(CEntry('r', "xml/strings.txt", ln, nm.substringAfter('/') + " = " + v.take(80).replace('\n', ' '), t.hex(k)))
            }
        }
        for (k in keys) {
            val nm = t.names[k] ?: continue
            val type = nm.substringBefore('/')
            if (type != "layout" && type != "menu" && type != "navigation") continue
            val v = t.values[k]?.firstOrNull { it.endsWith(".xml") } ?: continue
            out.add(CEntry(if (type == "layout") 'l' else 'r', "xml/$v", 1, nm.substringAfter('/'), t.hex(k)))
        }
        return out
    }

    fun save(file: File, list: List<CEntry>) {
        file.parentFile?.mkdirs()
        file.bufferedWriter().use { w ->
            for (e in list) {
                w.write(
                    e.kind + "\t" + e.path + "\t" + e.line + "\t" +
                        e.label.replace('\t', ' ').replace('\n', ' ') + "\t" + e.extra + "\n"
                )
            }
        }
    }

    fun loadAll(dir: File, idx: ConceptIndex) {
        val files = dir.listFiles()?.filter { it.name.endsWith(".tsv") }?.sortedBy { it.name } ?: return
        for (f in files) {
            val list = ArrayList<CEntry>()
            f.bufferedReader().useLines { seq ->
                for (line in seq) {
                    val p = line.split('\t')
                    if (p.size >= 4 && p[0].isNotEmpty()) {
                        list.add(CEntry(p[0][0], p[1], p[2].toIntOrNull() ?: 1, p[3], if (p.size > 4) p[4] else ""))
                    }
                }
            }
            idx.add(list)
        }
    }
}

/** In-memory inverted index over names, strings and resources, for "find by what it does" search. */
class ConceptIndex {
    private val entries = ArrayList<CEntry>()
    private val dict = HashMap<String, Int>()
    private val postings = ArrayList<IntList>()

    @Synchronized
    fun size(): Int = entries.size

    @Synchronized
    fun clear() {
        entries.clear()
        dict.clear()
        postings.clear()
    }

    @Synchronized
    fun add(list: List<CEntry>) {
        for (e in list) {
            if (entries.size >= 400_000) return
            val id = entries.size
            entries.add(e)
            for (w in Concept.words(e.label).map { Concept.stem(it) }.distinct()) {
                val tid = dict.getOrPut(w) {
                    postings.add(IntList())
                    postings.size - 1
                }
                postings[tid].add(id)
            }
        }
    }

    @Synchronized
    fun search(q: String, limit: Int): List<CEntry> {
        val groups = Concept.queryGroups(q)
        if (groups.isEmpty() || entries.isEmpty()) return emptyList()
        val n = entries.size
        val score = HashMap<Int, Float>()
        val matched = HashMap<Int, Int>()
        for (g in groups) {
            val seen = HashSet<Int>()
            for (st in g) {
                val tid = dict[st] ?: continue
                val p = postings[tid]
                if (p.n > 60_000) continue
                val idf = ln(1f + n.toFloat() / (1f + p.n))
                for (k in 0 until p.n) {
                    val e = p.a[k]
                    if (seen.add(e)) {
                        score[e] = (score[e] ?: 0f) + idf
                        matched[e] = (matched[e] ?: 0) + 1
                    }
                }
            }
        }
        if (score.isEmpty()) return emptyList()
        val need = if (groups.size >= 3) 2 else 1
        var cand = score.keys.filter { (matched[it] ?: 0) >= need }
        if (cand.size < 5) cand = score.keys.toList()
        val ranked = cand.map { e ->
            val cov = (matched[e] ?: 1).toFloat() / groups.size
            e to (score[e] ?: 0f) * (0.4f + cov) * weightOf(entries[e].kind)
        }.sortedByDescending { it.second }.take(limit * 3)
        val out = ArrayList<CEntry>()
        val seenKey = HashSet<String>()
        for ((e, _) in ranked) {
            val c = entries[e]
            if (seenKey.add(c.path + ":" + c.line)) out.add(c)
            if (out.size >= limit) break
        }
        return out
    }

    private fun weightOf(k: Char): Float = when (k) {
        'c' -> 1.4f
        'l' -> 1.3f
        'm' -> 1.2f
        'r' -> 1.1f
        'f' -> 0.9f
        else -> 1.0f
    }
}
