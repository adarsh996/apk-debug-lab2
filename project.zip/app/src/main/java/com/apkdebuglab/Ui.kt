package com.apkdebuglab

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

fun sizeStr(n: Long): String = when {
    n < 1024 -> "$n B"
    n < 1048576 -> "${n / 1024} KB"
    else -> "%.1f MB".format(n / 1048576.0)
}

fun highlight(text: String, re: Regex?): AnnotatedString = buildAnnotatedString {
    append(text)
    if (re != null) {
        try {
            for (m in re.findAll(text).take(60)) {
                if (m.range.last >= m.range.first) {
                    addStyle(
                        SpanStyle(background = Color(0xFFFFE08A), color = Color.Black),
                        m.range.first, m.range.last + 1
                    )
                }
            }
        } catch (e: Exception) {
        }
    }
}

private val Mono = FontFamily.Monospace

@Composable
fun AppRoot(vm: AppViewModel) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importUri(uri)
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("APK Debug Lab", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (vm.workspace != null && !vm.home) {
                TextButton(onClick = { vm.home = true }) { Text("Home") }
            }
        }
        if (vm.bgBusy && vm.dexTotal > 0) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Text("Reading code ${vm.dexDone}/${vm.dexTotal} (you can keep using the app)", fontSize = 11.sp, color = Color(0xFF1565C0))
                LinearProgressIndicator(
                    progress = { vm.dexDone.toFloat() / vm.dexTotal.toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else if (vm.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        Box(Modifier.weight(1f)) {
            if (vm.home || vm.workspace == null) HomeScreen(vm) { pick.launch(arrayOf("*/*")) }
            else WorkScreen(vm)
        }
        Text(
            vm.status, fontSize = 12.sp, maxLines = 2, color = Color.DarkGray,
            modifier = Modifier.fillMaxWidth().background(Color(0xFFEFEFEF)).padding(8.dp)
        )
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, pickApk: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    var showApps by remember { mutableStateOf(false) }
    val apps = vm.installed.filter {
        filter.isBlank() || it.label.contains(filter, true) || it.pkg.contains(filter, true)
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Debug and edit an app", style = MaterialTheme.typography.titleLarge) }
        item {
            Button(onClick = pickApk, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
                Text("Upload an APK file")
            }
        }
        item {
            OutlinedButton(
                onClick = { showApps = true; if (vm.installed.isEmpty()) vm.loadInstalled() },
                enabled = !vm.busy, modifier = Modifier.fillMaxWidth()
            ) { Text("Choose an installed app") }
        }
        if (vm.workspace != null) {
            item {
                OutlinedButton(onClick = { vm.home = false }, modifier = Modifier.fillMaxWidth()) {
                    Text("Resume: ${vm.appName}")
                }
            }
        }
        val crash = vm.crashText
        if (crash != null) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("The app closed unexpectedly last time", fontWeight = FontWeight.Bold)
                        SelectionContainer { Text(crash.take(900), fontFamily = Mono, fontSize = 10.sp) }
                        Text("Your app and progress were saved. If it keeps happening, send me this text.", fontSize = 12.sp)
                        TextButton(onClick = { vm.dismissCrash() }) { Text("Dismiss") }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Skip library code (faster)", fontWeight = FontWeight.Medium)
                        Text(
                            "Reads only the app's own classes, not big libraries like androidx or Firebase. Applies to the next app you open.",
                            fontSize = 11.sp, color = Color.Gray
                        )
                    }
                    Switch(checked = vm.skipLibs, onCheckedChange = { vm.setSkipLibs(it) })
                }
                if (vm.workspace != null) {
                    OutlinedButton(onClick = { vm.clearWorkspace() }, enabled = !vm.bgBusy) { Text("Delete saved app (free space)") }
                }
            }
        }
        item { AiSettings(vm) }
        if (showApps) {
            item {
                OutlinedTextField(
                    value = filter, onValueChange = { filter = it },
                    label = { Text("Filter installed apps") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            items(apps, key = { it.pkg }) { a ->
                Column(
                    Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.importInstalled(a) }
                        .padding(vertical = 6.dp)
                ) {
                    Text(a.label, fontSize = 15.sp)
                    Text(a.pkg, fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun AiSettings(vm: AppViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("AI assistant (optional)", style = MaterialTheme.typography.titleSmall)
        Text(
            "Everything except the AI tab works without a key. Pick a provider; free options need no card.",
            fontSize = 12.sp, color = Color.Gray
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (p in Providers.all) {
                FilterChip(
                    selected = vm.providerId == p.id,
                    onClick = { vm.selectProvider(p.id) },
                    label = { Text(p.label) }
                )
            }
        }
        Text(vm.provider.hint, fontSize = 12.sp, color = Color(0xFF1565C0))
        OutlinedTextField(
            value = vm.apiKey, onValueChange = { vm.apiKey = it },
            label = { Text(if (vm.provider.keyOptional) "API key (optional)" else "API key") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = vm.model, onValueChange = { vm.model = it },
            label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = vm.baseUrl, onValueChange = { vm.baseUrl = it },
            label = { Text("Server URL") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.saveSettings() }) { Text("Save") }
            OutlinedButton(onClick = { vm.saveSettings(); vm.testConnection() }, enabled = !vm.busy) {
                Text("Test connection")
            }
        }
    }
}

@Composable
fun WorkScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = vm.tab) {
            listOf("Preview", "Files", "Search", "AI", "Build").forEachIndexed { i, t ->
                Tab(selected = vm.tab == i, onClick = { vm.tab = i }, text = { Text(t, fontSize = 12.sp) })
            }
        }
        when (vm.tab) {
            0 -> PreviewTab(vm)
            1 -> FilesTab(vm)
            2 -> SearchTab(vm)
            3 -> AiTab(vm)
            else -> BuildTab(vm)
        }
    }
}

// ---------------- Files ----------------

private val hiddenNames = setOf("original.apk", "unsigned.apk", "stored.txt", "meta.txt")

private fun flatten(dir: File, base: File, expanded: List<String>, depth: Int, out: MutableList<Pair<File, Int>>) {
    val kids = dir.listFiles()
        ?.filter { !it.name.startsWith(".") && !it.name.startsWith("tmp_") && it.name !in hiddenNames }
        ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: return
    for (k in kids) {
        out.add(k to depth)
        if (k.isDirectory && expanded.contains(k.relativeTo(base).path)) {
            flatten(k, base, expanded, depth + 1, out)
        }
    }
}

@Composable
fun FilesTab(vm: AppViewModel) {
    if (vm.openPath != null) FileViewer(vm) else FileTree(vm)
}

@Composable
fun FileTree(vm: AppViewModel) {
    val ws = vm.workspace ?: return
    val exp = vm.expanded.toList()
    val rows = remember(exp, vm.tick, ws) {
        val out = ArrayList<Pair<File, Int>>()
        flatten(ws, ws, exp, 0, out)
        out
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Text(
                "smali = editable code, xml = decoded read-only views, files = raw APK files",
                fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(12.dp)
            )
        }
        items(rows, key = { it.first.path }) { (f, d) ->
            val rel = f.relativeTo(ws).path
            val isOpen = exp.contains(rel)
            Row(
                Modifier.fillMaxWidth()
                    .clickable {
                        if (f.isDirectory) {
                            if (vm.expanded.contains(rel)) vm.expanded.remove(rel) else vm.expanded.add(rel)
                        } else vm.open(rel)
                    }
                    .padding(start = (12 + d * 14).dp, top = 8.dp, bottom = 8.dp, end = 12.dp)
            ) {
                Text(
                    (if (f.isDirectory) (if (isOpen) "▾ " else "▸ ") else "") + f.name,
                    modifier = Modifier.weight(1f), fontSize = 13.sp, fontFamily = Mono
                )
                if (f.isFile) Text(sizeStr(f.length()), fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun FileViewer(vm: AppViewModel) {
    val replace = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.replaceOpen(uri)
    }
    val path = vm.openPath ?: return
    val text = vm.openText
    val readOnly = path.startsWith("xml/")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.closeFile() }) { Text("‹ Back") }
            Text(path, fontSize = 11.sp, maxLines = 2, modifier = Modifier.weight(1f))
            if (text != null && !readOnly && vm.openSize < 400_000) {
                if (vm.editing) {
                    TextButton(onClick = { vm.saveOpen() }) { Text("Save") }
                } else {
                    TextButton(onClick = { vm.editBuffer = text; vm.editing = true }) { Text("Edit") }
                }
            }
        }
        if (readOnly) {
            Text(
                "Decoded view of a binary XML file. Read-only: edits here can't be rebuilt into the APK yet.",
                fontSize = 11.sp, color = Color(0xFF8D6E00),
                modifier = Modifier.fillMaxWidth().background(Color(0xFFFFF8E1)).padding(6.dp)
            )
        }
        if (text == null) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Binary file (${sizeStr(vm.openSize)}).")
                Text("A built-in hex editor isn't included yet. You can replace this file with one from your phone.")
                Button(onClick = { replace.launch(arrayOf("*/*")) }) { Text("Replace with a file…") }
            }
        } else if (vm.editing) {
            OutlinedTextField(
                value = vm.editBuffer, onValueChange = { vm.editBuffer = it },
                modifier = Modifier.fillMaxSize().padding(8.dp),
                textStyle = TextStyle(fontFamily = Mono, fontSize = 12.sp)
            )
        } else {
            CodeView(vm, text)
        }
    }
}

@Composable
fun CodeView(vm: AppViewModel, text: String) {
    val lines = remember(text) { text.split("\n") }
    val state = rememberLazyListState()
    LaunchedEffect(vm.openPath, vm.openLine, lines.size) {
        if (vm.openLine > 0) state.scrollToItem(maxOf(0, vm.openLine - 4))
    }
    val re = vm.hlRe ?: remember(vm.query, vm.useRegex, vm.caseSens, vm.res) { vm.currentRegex() }
    LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
        itemsIndexed(lines) { i, l ->
            val hot = (i + 1 == vm.openLine)
            Row(
                Modifier.fillMaxWidth()
                    .background(if (hot) Color(0x55FFC107) else Color.Transparent)
            ) {
                Text("${i + 1}".padStart(5) + " ", fontFamily = Mono, fontSize = 11.sp, color = Color.Gray)
                Text(highlight(l, re), fontFamily = Mono, fontSize = 11.sp)
            }
        }
    }
}

// ---------------- Search ----------------

@Composable
fun SearchTab(vm: AppViewModel) {
    val plain = remember(vm.query, vm.useRegex, vm.caseSens, vm.res) { vm.currentRegex() }
    val re = vm.hlRe ?: plain
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(
                value = vm.query, onValueChange = { vm.query = it },
                label = { Text("Function, logic, class, id or a question") }, maxLines = 3,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.runSearch() })
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(selected = vm.useRegex, onClick = { vm.useRegex = !vm.useRegex }, label = { Text("Regex") })
                FilterChip(selected = vm.caseSens, onClick = { vm.caseSens = !vm.caseSens }, label = { Text("Case") })
                Button(onClick = { vm.runSearch() }, enabled = !vm.busy) { Text("Search") }
                OutlinedButton(
                    onClick = { vm.conceptSearch(vm.query) },
                    enabled = !vm.busy && vm.query.isNotBlank()
                ) { Text("By feature") }
                OutlinedButton(
                    onClick = { if (vm.aiReady) vm.ask(vm.query) else vm.conceptSearch(vm.query) },
                    enabled = !vm.busy && vm.query.isNotBlank()
                ) { Text(if (vm.aiReady) "Ask AI" else "Ask") }
            }
            Text(
                "By feature: describe what it does, e.g. \"block generator\" or \"save score\". It finds matching code by meaning, not exact text.",
                fontSize = 11.sp, color = Color.Gray
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vm.extFilter, onValueChange = { vm.extFilter = it },
                    label = { Text("Types: smali,xml") }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vm.folderFilter, onValueChange = { vm.folderFilter = it },
                    label = { Text("Folder / package") }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(vm.hits) { i, h ->
                Column {
                    if (i == 0 || vm.hits[i - 1].path != h.path) {
                        Text(
                            h.path, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth().clickable { vm.open(h.path) }
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        )
                    }
                    HitCard(vm, h, re)
                }
            }
        }
    }
}

@Composable
fun HitCard(vm: AppViewModel, h: Hit, re: Regex?) {
    var ctxText by remember(h) { mutableStateOf<String?>(null) }
    Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp)) {
        Column(Modifier.padding(8.dp)) {
            Text("line ${h.line}", fontSize = 11.sp, color = Color.Gray)
            Text(highlight(h.text.trim(), re), fontFamily = Mono, fontSize = 12.sp)
            Row {
                val pad = PaddingValues(horizontal = 8.dp)
                TextButton(onClick = { vm.open(h.path, h.line) }, contentPadding = pad) { Text("Open", fontSize = 12.sp) }
                TextButton(
                    onClick = { ctxText = if (ctxText == null) vm.contextFor(h) else null },
                    contentPadding = pad
                ) { Text("Context", fontSize = 12.sp) }
                TextButton(onClick = { vm.usages(h) }, contentPadding = pad) { Text("Usages", fontSize = 12.sp) }
                TextButton(onClick = { vm.askAbout(h) }, contentPadding = pad) { Text("Ask AI", fontSize = 12.sp) }
            }
            val c = ctxText
            if (c != null) {
                Text(
                    highlight(c, re), fontFamily = Mono, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFF5F5F5)).padding(6.dp)
                )
            }
        }
    }
}

// ---------------- AI ----------------

private val REF = Regex("([\\w./\\$@-]+\\.(?:smali|xml|java|kt|json|txt|properties|js|html)):(\\d+)")

@Composable
fun AiTab(vm: AppViewModel) {
    var withSearch by remember { mutableStateOf(false) }
    var withFile by remember { mutableStateOf(false) }
    val state = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.pendingEdits.size) {
        val n = state.layoutInfo.totalItemsCount
        if (n > 0) state.animateScrollToItem(n - 1)
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp), state = state) {
            if (!vm.aiReady) {
                item {
                    Card(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("AI is not set up yet", fontWeight = FontWeight.Bold)
                            Text(
                                "Search, preview, editing and rebuilding all work without it. To use the assistant, " +
                                    "open Home > AI assistant and add a key. Gemini and Groq have free keys with no card.",
                                fontSize = 13.sp
                            )
                            Button(onClick = { vm.home = true }) { Text("Open AI settings") }
                        }
                    }
                }
            } else if (vm.messages.isEmpty()) {
                item {
                    Text(
                        "Describe a feature (\"block generator\"), ask why something crashes, or give a change command " +
                            "(\"make it create 10 blocks\"). The assistant finds the code itself and proposes edits for you to approve.",
                        modifier = Modifier.padding(12.dp), color = Color.Gray
                    )
                }
            }
            items(vm.messages) { m ->
                if (m.tool) {
                    Text("⚙ " + m.text, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
                } else {
                    val refs = remember(m.text) {
                        REF.findAll(m.text)
                            .map { it.groupValues[1] to (it.groupValues[2].toIntOrNull() ?: 0) }
                            .filter { (p, _) -> p.startsWith("smali/") || p.startsWith("xml/") || p.startsWith("files/") }
                            .distinct().take(6).toList()
                    }
                    Card(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (m.fromUser) Color(0xFFEDE7F6) else Color(0xFFF5F5F5)
                        )
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            SelectionContainer {
                                Text((if (m.fromUser) "You: " else "") + m.text, fontSize = 13.sp)
                            }
                            if (refs.isNotEmpty()) {
                                Row(Modifier.horizontalScroll(rememberScrollState())) {
                                    for ((p, ln) in refs) {
                                        TextButton(
                                            onClick = { vm.open(p, ln) },
                                            contentPadding = PaddingValues(horizontal = 6.dp)
                                        ) { Text(p.substringAfterLast('/') + ":" + ln, fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            items(vm.pendingEdits.toList()) { e ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                ) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Proposed edit: ${e.path}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(e.reason, fontSize = 12.sp)
                        Text("- " + e.find.take(500), fontFamily = Mono, fontSize = 11.sp, color = Color(0xFFC62828))
                        Text("+ " + e.replace.take(500), fontFamily = Mono, fontSize = 11.sp, color = Color(0xFF2E7D32))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { vm.approve(e) }, enabled = !vm.busy) { Text("Apply") }
                            OutlinedButton(onClick = { vm.dismiss(e) }) { Text("Dismiss") }
                            TextButton(onClick = { vm.open(e.path) }) { Text("View file") }
                        }
                    }
                }
            }
            if (vm.pendingEdits.size > 1) {
                item {
                    OutlinedButton(onClick = { vm.approveAll() }, enabled = !vm.busy) {
                        Text("Apply all ${vm.pendingEdits.size} edits")
                    }
                }
            }
        }
        Row(
            Modifier.padding(horizontal = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TextButton(onClick = { vm.chatInput = "Where is the code for this feature, and how does it work: " }) { Text("Find feature", fontSize = 12.sp) }
            TextButton(onClick = { vm.chatInput = "Find bugs or crash risks in: " }) { Text("Find bugs", fontSize = 12.sp) }
            TextButton(onClick = { vm.chatInput = "Change the code so that " }) { Text("Make a change", fontSize = 12.sp) }
            if (vm.undoCount > 0) {
                TextButton(onClick = { vm.undoLast() }) { Text("Undo last edit (${vm.undoCount})", fontSize = 12.sp) }
            }
        }
        Row(
            Modifier.padding(horizontal = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = withSearch, onClick = { withSearch = !withSearch }, label = { Text("Attach search results") })
            FilterChip(selected = withFile, onClick = { withFile = !withFile }, label = { Text("Attach open file") })
            FilterChip(selected = vm.autoApply, onClick = { vm.autoApply = !vm.autoApply }, label = { Text("Auto-apply edits") })
        }
        Row(
            Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = vm.chatInput, onValueChange = { vm.chatInput = it },
                label = { Text("Ask about the code") }, maxLines = 5, modifier = Modifier.weight(1f)
            )
            Button(onClick = { vm.sendChat(withSearch, withFile) }, enabled = !vm.busy) { Text("Send") }
        }
    }
}

// ---------------- Build ----------------

@Composable
fun BuildTab(vm: AppViewModel) {
    val ctx = LocalContext.current
    val save = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri -> if (uri != null) vm.saveApkTo(uri) }
    Column(
        Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Rebuild", style = MaterialTheme.typography.titleMedium)
        Text(
            "Edited smali is reassembled into dex, all files are repacked, and the APK is signed " +
                "with this app's built-in key. Changes to the decoded xml/ views are not included.",
            fontSize = 13.sp
        )
        Button(onClick = { vm.rebuild() }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Rebuild and sign APK")
        }
        val apk = vm.lastApk
        if (apk != null) {
            Text("${apk.name} (${sizeStr(apk.length())})", fontSize = 13.sp)
            Button(onClick = { ctx.startActivity(ApkTools.installIntent(ctx, apk)) }, modifier = Modifier.fillMaxWidth()) {
                Text("Install")
            }
            OutlinedButton(onClick = { save.launch(apk.name) }, modifier = Modifier.fillMaxWidth()) {
                Text("Save a copy")
            }
        }
        Text(
            "Note: the rebuilt APK has a different signature than the original, so to replace an " +
                "installed app you must uninstall it first (its data is lost). Android will ask you to " +
                "allow installing from this app.",
            fontSize = 12.sp, color = Color.Gray
        )
        if (vm.buildLog.isNotBlank()) Text(vm.buildLog, fontFamily = Mono, fontSize = 11.sp)
    }
}
