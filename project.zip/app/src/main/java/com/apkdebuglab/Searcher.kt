package com.apkdebuglab

import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

data class Hit(val path: String, val line: Int, val text: String)
class IdxFile(val file: File, val rel: String, val ext: String)

object Searcher {
    const val MAX = 600

    fun isText(f: File): Boolean {
        if (!f.isFile) return false
        return try {
            f.inputStream().use { i ->
                val buf = ByteArray(4096)
                val n = i.read(buf)
                for (k in 0 until maxOf(n, 0)) {
                    if (buf[k] == 0.toByte()) return false
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun regexFor(q: String, regex: Boolean, caseSens: Boolean): Regex {
        val opts: Set<RegexOption> = if (caseSens) emptySet() else setOf(RegexOption.IGNORE_CASE)
        return Regex(if (regex) q else Regex.escape(q), opts)
    }

    /** One-time list of every searchable text file (smali, decoded xml, plain text assets). */
    fun buildIndex(ws: File): List<IdxFile> {
        val out = ArrayList<IdxFile>()
        for (root in listOf("smali", "xml", "files")) {
            val dir = File(ws, root)
            if (!dir.exists()) continue
            for (f in dir.walkTopDown()) {
                if (!f.isFile || f.length() > 5_000_000) continue
                val ext = f.extension.lowercase()
                val known = ext == "smali" || root == "xml"
                if (known || isText(f)) {
                    out.add(IdxFile(f, f.relativeTo(ws).path.replace('\\', '/'), ext))
                }
            }
        }
        out.sortBy { it.rel }
        return out
    }

    /** Index just one freshly written smali folder. */
    fun indexDir(ws: File, dir: File): List<IdxFile> {
        val out = ArrayList<IdxFile>()
        for (f in dir.walkTopDown()) {
            if (f.isFile && f.name.endsWith(".smali")) {
                out.add(IdxFile(f, f.relativeTo(ws).path.replace('\\', '/'), "smali"))
            }
        }
        return out
    }

    private fun rank(hits: List<Hit>): List<Hit> {
        val groups = LinkedHashMap<String, MutableList<Hit>>()
        for (h in hits) groups.getOrPut(h.path) { ArrayList() }.add(h)
        fun score(g: List<Hit>): Int {
            var s = minOf(g.size, 9)
            if (g.any {
                    val t = it.text.trimStart()
                    t.startsWith(".method") || t.startsWith(".class") || t.startsWith(".field")
                }
            ) s += 20
            return s
        }
        return groups.values.sortedByDescending { score(it) }.flatten()
    }

    /** Multi-threaded search over the prebuilt index. */
    fun search(index: List<IdxFile>, re: Regex, exts: List<String>, folder: String, max: Int = MAX): List<Hit> {
        val fol = if (folder.contains('/')) folder else folder.replace('.', '/')
        val cand = index.filter {
            (fol.isEmpty() || it.rel.contains(fol, ignoreCase = true)) &&
                (exts.isEmpty() || it.ext in exts)
        }
        if (cand.isEmpty()) return emptyList()
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
        val pool = Executors.newFixedThreadPool(threads)
        val count = AtomicInteger(0)
        try {
            val size = maxOf(1, cand.size / (threads * 4) + 1)
            val futures = cand.chunked(size).map { chunk ->
                pool.submit(Callable<List<Hit>> {
                    val part = ArrayList<Hit>()
                    for (f in chunk) {
                        if (count.get() >= max) break
                        try {
                            var n = 0
                            f.file.bufferedReader().useLines { seq ->
                                for (line in seq) {
                                    n++
                                    if (re.containsMatchIn(line)) {
                                        part.add(Hit(f.rel, n, line.take(400)))
                                        if (count.incrementAndGet() >= max) break
                                    }
                                }
                            }
                        } catch (e: Exception) {
                        }
                    }
                    part
                })
            }
            val all = ArrayList<Hit>()
            for (fu in futures) all.addAll(fu.get())
            return rank(all).take(max)
        } finally {
            pool.shutdown()
        }
    }

    /** The enclosing smali method (or +-6 lines for other files), numbered. */
    fun context(ws: File, h: Hit, radius: Int = 6): String {
        val lines = try {
            File(ws, h.path).readLines()
        } catch (e: Exception) {
            return ""
        }
        if (lines.isEmpty()) return ""
        val idx = (h.line - 1).coerceIn(0, lines.size - 1)
        var s = maxOf(0, idx - radius)
        var e = minOf(lines.size - 1, idx + radius)
        if (h.path.endsWith(".smali")) {
            var a = idx
            while (a > 0 && !lines[a].startsWith(".method") &&
                !(a < idx && lines[a].startsWith(".end method"))
            ) a--
            if (lines[a].startsWith(".method")) {
                var b = idx
                while (b < lines.size - 1 && !lines[b].startsWith(".end method")) b++
                s = a
                e = minOf(b, a + 150)
            }
        }
        val sb = StringBuilder()
        for (i in s..e) sb.append(i + 1).append("  ").append(lines[i]).append('\n')
        return sb.toString()
    }

    /** What to search for to find usages of the thing on this line. */
    fun usageQuery(h: Hit): String {
        val t = h.text.trim()
        val hexLead = Regex("^0x[0-9a-fA-F]{8}").find(t)
        if (hexLead != null) return hexLead.value
        if (t.startsWith(".method")) {
            val name = t.substringBefore('(').substringAfterLast(' ')
            if (name.isNotEmpty()) return "->$name("
        }
        if (t.startsWith(".class")) {
            val d = t.substringAfterLast(' ')
            if (d.isNotEmpty()) return d
        }
        val m = Regex("L[\\w/$]+;->[\\w$<>]+").find(t)
        if (m != null) return m.value
        return t.take(80)
    }
}
